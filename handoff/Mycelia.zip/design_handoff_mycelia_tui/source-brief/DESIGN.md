# mycelia — TUI Design Document

A brief for designing the terminal interface of `mycelia`. Pair this with `CHARTER.md` for the system's intent and architecture; this document is concerned only with how it looks, feels, and is operated.

---

## 1. Aesthetic target

### Reference points

- **`btop`** — the primary touchstone. Density, live data, generous use of box-drawing characters, gauges, sparklines, distinct colour-coded zones. The feeling that the screen is *alive*.
- **`lazygit`** — clean multi-pane layout with clear focus indication, tasteful use of colour for state.
- **`htop` / `bottom`** — restrained density, clear typographic hierarchy in a monospace world.
- **`jrnl`, `taskwarrior`** — anti-references for visual style (too plain) but reference points for command grammar.

### Mood

A thinking environment, not a dashboard. The visual register is **dense but unhurried**. Information is everywhere on the screen, but nothing flashes for attention. The system is a quiet workshop, not a cockpit.

`btop` is the inspiration for density and structure, not for tone. `mycelia` should feel closer to a well-organised desk than a server monitor. Less "system under load," more "a record of a working mind."

### Lean into

- Box-drawing characters for panel borders (`╭─╮`, `├─┤`, `╰─╯`) — soft rounded corners, never hard 90°.
- Unicode block characters for sparklines and density visuals (`▁▂▃▄▅▆▇█`).
- Colour as state and meaning, not decoration. A muted base palette with a few saturated accents reserved for urgency.
- Whitespace inside panels. Density of *information* does not mean density of *characters*.
- Live updates that feel like breathing — not animation for animation's sake.

### Avoid

- ASCII art logos, banner text, anything that takes vertical space without conveying information.
- Emoji as UI (acceptable sparingly in user content; never in chrome).
- Hard right-angle borders (`+---+`). They read as 1990s.
- More than three colours competing for attention at once.
- Loading spinners that suggest the system is slow. If something is slow, show *what it is doing*, not that it is doing something.
- Animations on data changes. Live updates should be instant and silent.

---

## 2. Screens

`mycelia` has one primary screen — the **workspace** — and a small number of focused secondary views that take over when invoked. The user spends 95% of their time on the workspace.

### 2.1 Workspace (primary)

The default screen. Always available. Composed of fixed panels in a grid, plus a command bar at the bottom.

Suggested layout at full terminal width (~120 cols × 40 rows):

```
╭─ mycelia ──────────────────────────────────────────── 2026-05-19 Tue ─╮
│ ┌─ today ──────────┐ ┌─ journal ───────────────────────┐ ┌─ feed ───┐ │
│ │ tasks            │ │ today's entry, edited inline   │ │ activity │ │
│ │ overdue, due,    │ │                                 │ │ stream   │ │
│ │ in-progress      │ │                                 │ │          │ │
│ │                  │ │                                 │ │          │ │
│ │                  │ │                                 │ │          │ │
│ └──────────────────┘ └─────────────────────────────────┘ └──────────┘ │
│ ┌─ threads ────────┐                                   ┌─ pulse ────┐ │
│ │ active AI convos │                                   │ sparklines │ │
│ └──────────────────┘                                   └────────────┘ │
├───────────────────────────────────────────────────────────────────────┤
│ ❯ _                                                       AI: read    │
╰───────────────────────────────────────────────────────────────────────╯
```

Panel responsibilities:

- **today** — tasks due, overdue, or in-progress. Sorted overdue → due-today → no-date. One line per task.
- **journal** — the current day's journal file, rendered with light markdown styling. Editable in place when focused.
- **feed** — chronological activity stream. Items: tasks completed, notes touched, AI threads updated, sync events. Last ~20 items, newest at top.
- **threads** — list of active AI conversation threads. Title, model, last activity. Selectable to open the thread view.
- **pulse** — small sparklines for at-a-glance metrics. Suggested: tasks completed per day (7 days), words written per day (7 days), AI calls per day (7 days). One line each.
- **command bar** — bottom strip, full width. Persistent. Prompt character on the left, active AI profile on the right.

### 2.2 Thread view

Replaces the workspace when an AI thread is open. Two-pane:

- **Left (narrow)**: thread metadata and history. Model in use, profile, token count, cost, list of past turns.
- **Right (wide)**: the conversation. User turns and AI turns differentiated by colour and indentation. AI turns stream in live. Tool calls (Claude reading a file, Kimi tagging a batch) render as collapsible blocks.

The command bar stays at the bottom; in thread view, typing into it sends the next message in the thread rather than executing a slash command (unless prefixed).

### 2.3 Review queue

A focused list of AI-proposed changes awaiting decision. Each item:

- What was proposed (a diff, a new file, a tagging change).
- Which AI proposed it and under which profile.
- When.
- Three actions: `[a]ccept`, `[r]eject`, `[e]dit`.

The view is keyboard-driven, no mouse. Up/down to navigate, the action keys to decide.

### 2.4 Search

Triggered by `/find` or `Ctrl-F`. A single input at the top, results below grouped by type (notes / tasks / journal / threads). Live as you type. Selecting a result opens it in the appropriate view.

### 2.5 Help / command reference

Triggered by `?` or `/help`. A modal overlay with the full command grammar, keyboard map, and current profile rules. Dismissed with any key.

---

## 3. Components

Reusable visual elements that appear across screens.

### 3.1 Panel

The atomic unit. A bordered region with:

- A **title** in the top border (`╭─ title ─╮`), single space padding around the word.
- A **body** with one character of padding from the border on left and right.
- An optional **count indicator** in the top-right of the border (`╭─ tasks ──── 7 ─╮`) for panels with countable items.
- An optional **focus indicator**: the border colour shifts to the accent colour when focused; unfocused panels use a muted border.

### 3.2 Task line

A single task rendered on one line. From left to right:

```
 ●  Buy oat milk                         #errands   tue
```

- **Status glyph**: `○` open, `◐` in-progress, `●` done (faded), `!` overdue (accent colour), `~` deferred.
- **Title**: the task body, truncated with `…` if too long.
- **Tags**: right-aligned, dim colour, prefixed with `#`.
- **Date**: rightmost, short form (`tue`, `5/22`, `next wk`).

### 3.3 Journal line

Within the journal panel, the day's entry renders with light markdown styling:

- Headings get bold and a slight colour shift.
- Lists get a left margin and a `·` glyph instead of `-`.
- Inline code gets a subtle background.
- Links underline on hover/focus (where the terminal supports it).
- Captured items (`/in`) appear under a `### inbox` heading at the top of the file, dim and indented.

### 3.4 Feed item

One line per event:

```
 14:32  task    ✓ Buy oat milk
 14:30  ai      claude /ask — "what have I been avoiding"
 14:12  note    edited  weekly-review-2026-05-w20
 14:01  sync    pushed  3 changes to notion
```

Time, type tag, summary. Type tag is colour-coded but muted.

### 3.5 Thread item

In the threads panel:

```
 ● weekly review            claude   2m
 ○ refactor inbox tagging   kimi    23m
```

Active-dot glyph (filled if the thread has been updated since last viewed), title, model, time since last activity. Click/select opens the thread view.

### 3.6 Sparkline

A single line of Unicode block characters showing the last 7 (or 30) data points:

```
 tasks  ▂▄▃▅█▆▂  4 today
 words  ▁▂▁▅▃▇▆  812 today
 ai     ▃▂▄▆█▅▃  17 today
```

Label, sparkline, current value. The sparkline uses the muted accent; the current value uses the panel's normal text colour.

### 3.7 Command bar

Always at the bottom, full width. Components:

- **Prompt glyph** (`❯`) at the far left, in the accent colour.
- **Input area** consuming the middle.
- **Mode indicator** at the far right: `AI: read`, `AI: draft`, `AI: act`, colour-coded (`read` = muted, `draft` = warm accent, `act` = strong accent / red).
- **Ghost text** showing the most likely completion in dim grey, accepted with `Tab`.

The command bar is **modal by syntax**, not by toggle:

- Plain text → appended to today's journal.
- Starts with `/` → slash command.
- Starts with `?` → question to the current AI thread (or starts a new one if none active).
- Starts with `!` → shell passthrough (executes in the repo cwd, output goes to feed).

### 3.8 Status bar (top)

Inside the outer frame, the top border doubles as a status bar:

```
╭─ mycelia ──────────────────── 2026-05-19 Tue ── ↑ synced 2m ago ──╮
```

Left: app name. Centre: date. Right: sync status, with a small glyph (`↑` synced, `↻` syncing, `⚠` conflict, `·` offline).

### 3.9 Diff block (review queue)

For AI-proposed edits, render unified diffs with:

- Removed lines: muted red foreground, no background.
- Added lines: muted green foreground, no background.
- Context lines: default colour, dim.
- File path as a small header above the diff.

No syntax highlighting. The diff is information, not decoration.

---

## 4. Layout grammar

### Grid

The workspace is a **12-column flexbox grid**. Default proportions at full width:

- today: 3 cols
- journal: 6 cols
- feed: 3 cols
- threads: 3 cols
- pulse: 3 cols

Rows are flexible: today/journal/feed take the upper ~70% of vertical space; threads/pulse fill the lower ~30%; command bar is fixed at 1 row.

### Responsive behaviour

The TUI must remain usable at 80 cols × 24 rows (the classic terminal minimum). Below 100 cols, collapse to:

- A single tall panel showing one of {today, journal, feed, threads}.
- A tab strip at the top to switch between them.
- The command bar persists.

Between 100 and 120 cols, drop the threads and pulse panels (move them behind keyboard shortcuts `t` and `p`), keep today / journal / feed.

### Focus model

One panel is always focused. The focused panel gets:

- A brighter border in the accent colour.
- Keyboard input routed to it (when not in the command bar).
- A small focus indicator in the panel title: `╭─ today ◉ ──╮`.

Focus moves via:

- `Tab` / `Shift-Tab` — cycle through panels.
- `Ctrl-1`..`Ctrl-5` — jump to panel by number.
- `Esc` — return focus to the command bar.

---

## 5. Information density

A hierarchy from most to least prominent:

1. **Overdue tasks** — accent colour, top of `today`, never collapsed.
2. **Today's journal entry** — the largest panel, centre of the screen.
3. **Active AI thread updates** — animate (gently) when streaming, draw the eye.
4. **Recently completed tasks** — muted but visible in the feed.
5. **Pulse sparklines** — visible but lowest weight; ambient signal.
6. **Sync status** — corner of the status bar, only loud when wrong.

Rule of thumb: **anything that is wrong, late, or needs decision is in the accent colour. Everything else lives in the muted base.** The user's eye should be drawn to what needs them.

---

## 6. Interaction model

### Keyboard-first, mouse-tolerant

Every action must be keyboard-accessible. Mouse support is a bonus where the terminal allows it (clicking panels to focus, scrolling feed/journal), but never required.

### The command bar grammar

```
                  enters journal
                  ↓
 ❯ went for a run this morning, felt good
 ❯ /todo add finish charter   #mycelia  due:fri
 ❯ /ask what have I been avoiding this week
 ❯ ? continue that thought    (sends to active thread)
 ❯ !git status                (shell passthrough)
```

Slash commands (initial set):

- `/todo add <text>` — add a task. Frontmatter inferred from inline syntax (`#tag`, `due:fri`, `proj:mycelia`).
- `/todo done <id|partial-title>` — complete a task.
- `/todo list` — open a task-focused view.
- `/note new <title>` — create a new note, open in journal panel for editing.
- `/note find <query>` — search notes, results in feed.
- `/journal yesterday` — open yesterday's journal (or any relative day).
- `/in <text>` — append to today's inbox.
- `/ask <prompt>` — ask Claude in a new thread (`read` profile).
- `/think` — same as `/ask` but enters thread view immediately.
- `/draft <prompt>` — ask Claude to draft something into `drafts/` (`draft` profile).
- `/tag <selector>` — bulk tag via Kimi.
- `/triage inbox` — Kimi pre-processes, Claude reviews, results to review queue.
- `/agent <prompt>` — full-tool AI run (`act` profile). Confirmation required.
- `/review` — open review queue.
- `/sync` — manual sync now.
- `/find <query>` — open search.
- `/help` — help modal.

### Keyboard shortcuts (initial set)

Global:

- `Esc` — focus command bar.
- `Tab` / `Shift-Tab` — cycle panel focus.
- `Ctrl-1..5` — jump to panel.
- `?` — help.
- `Ctrl-C` — cancel current operation; second press within 1s quits.
- `Ctrl-R` — open review queue.

In `today` panel:

- `j` / `k` — down / up.
- `Enter` — open task in detail view.
- `Space` — toggle status (open ↔ in-progress).
- `x` — mark done.
- `d` — set due date (prompts).
- `e` — edit task body.

In `journal` panel:

- `i` — enter insert mode at cursor.
- `o` — new line below, insert mode.
- `Esc` — leave insert mode.
- Modal vim-style editing is acceptable here because the journal is the one place users write at length.

In `threads` panel:

- `j` / `k` — navigate.
- `Enter` — open thread.
- `n` — new thread.
- `d` — archive thread.

In thread view:

- `Esc` `Esc` — back to workspace.
- `Ctrl-S` — save thread as note in `notes/`.
- `r` — change profile for next message.

In review queue:

- `a` — accept.
- `r` — reject.
- `e` — edit before accepting.
- `j` / `k` — navigate.

### Modes

The TUI is **modeless by default**, with one exception: the `journal` panel uses a light vim-style insert/normal split because users will write paragraphs there. Everywhere else, keys do the same thing regardless of context.

---

## 7. State indicators

The user must always know:

- **What panel has focus** — bright accent border, focus glyph in title.
- **What AI profile is active** — right side of command bar, colour-coded.
- **Whether AI is currently running** — a subtle progress glyph (`⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏`) animated next to the active thread name, or in the thread view's header.
- **Whether sync is healthy** — glyph in the top-right status bar.
- **Whether there are pending review items** — a count indicator on the workspace, e.g. `╭─ mycelia ── review: 3 ──╮` when nonzero.
- **Whether the daemon is alive** — if it dies, the TUI shows a banner across the bottom in the warning colour. The TUI itself never crashes when the daemon does.

---

## 8. Colour and typography

### Palette

Designed for both dark and light terminals. The designer should produce both variants. Below describes the dark default.

- **Base background** — terminal default (transparent). Never set a background colour for the whole TUI.
- **Foreground (default)** — terminal default foreground.
- **Muted** — ~40% opacity equivalent. Used for borders, dim text, timestamps, secondary info.
- **Dim accent** — a single hue at low saturation. Used for focused-panel borders and the prompt glyph. Suggested: a soft teal or muted gold. The designer's call.
- **Strong accent** — same hue, higher saturation. Used for overdue, errors, the `act` profile indicator.
- **Success** — muted green. Used for completed tasks, successful sync, accepted review items.
- **Warning** — muted amber. Used for `draft` profile, pending review count, sync warnings.
- **Danger** — muted red. Used for `act` profile, errors, conflicts.

The whole palette should sit comfortably with the terminal's existing 16-colour scheme. Do not introduce a 257th colour where one of the existing ones works.

### Typography

A monospace world has limited typography levers. The available ones:

- **Weight** — bold for emphasis, sparingly. Never bold whole panels.
- **Colour** — see palette above.
- **Case** — Title Case for panel titles, sentence case for body content.
- **Glyphs** — Unicode glyphs (`◉ ○ ● ◐ ↑ ↓ ↻ ⚠ ✓ ✗ ⠋`) carry meaning. Used consistently.
- **Width** — alignment via padding, not via tabs.

Box-drawing characters: prefer the **light rounded** set (`╭─╮│╰─╯├┤┬┴┼`). Never mix with the heavy set in the same view.

---

## 9. Motion and live updates

The TUI is **live but quiet**. Updates appear instantly when data changes; no transitions, no fades, no slide-ins.

Three exceptions where motion is allowed:

1. **Streaming AI text** — token-by-token append in the thread view. The cursor visibly advances. This is the system thinking out loud and should feel that way.
2. **Progress glyphs** — the braille spinner for active AI calls. Slow and steady, not frantic.
3. **Sparkline updates** — when a new data point arrives, the line shifts left by one character. No animation, just the next frame.

Things that do *not* animate:

- Panel changes when data arrives. They just update.
- Focus transitions. The border colour changes; that's it.
- Modal opens. The modal appears.

---

## 10. Edge cases and empty states

### Empty states

Every panel needs an empty state. The empty state is **a quiet message in muted text**, not an illustration.

- **today (no tasks)**: `nothing due. press / to add.`
- **journal (no entry today)**: `start typing to begin today's entry.`
- **feed (nothing recent)**: `quiet here. activity will appear.`
- **threads (none active)**: `no active threads. /ask to start one.`
- **pulse (no data yet)**: just the labels with `—` instead of a sparkline.
- **review queue (empty)**: `nothing to review.`

### Errors

Errors appear in the feed as the type tag `error`, in the warning or danger colour. Persistent errors (daemon down, sync broken for >1h) get a banner above the command bar:

```
├─ daemon unreachable — files still editable in $EDITOR ──────────┤
```

### Long content

- Tasks: truncate to one line with `…`, full body in detail view.
- Feed: each item is one line; multi-line content is summarised.
- Threads list: title truncated, last activity is always shown.
- Journal: scrolls within the panel; never resizes the panel.

### Narrow terminals

See section 4 (responsive behaviour). Below 80 cols, show only the command bar and the focused panel, full-screen.

### Accessibility

- All colour-encoded states must also have a glyph or text label. `overdue` is `!` in red, not just red.
- High-contrast palette variant: a separate config-driven theme using only terminal colours 0–15.
- All actions reachable by keyboard.

---

## 11. Deliverables for the design pass

When this brief comes back from design work, the artefacts should be:

1. **Static mockups** of each screen at full-width (120×40) and narrow (80×24), in both dark and light variants. Plain text with ANSI colour preferred over images; images acceptable for sharing.
2. **A component sheet** showing each component (panel, task line, feed item, etc.) in its states: default, focused, hover (if applicable), disabled.
3. **A colour spec**: the chosen accent hue, the warning/danger/success values, suggested terminal colour codes for both dark and light variants.
4. **A keyboard map** as a one-page reference, suitable for `/help`.
5. **A glyph catalogue**: every Unicode glyph used in the chrome, with its meaning.
6. **Notes on any decisions** that overrode this brief, with reasoning.

---

## 12. Constraints to honour

- **Monospace only.** All design assumes a fixed-width font. No proportional spacing.
- **Box-drawing characters render correctly** in iTerm2, kitty, alacritty, wezterm, and the default macOS Terminal. Designs that depend on rare Unicode glyphs need a fallback.
- **256-colour terminals are the floor.** Truecolour (24-bit) is the design target, but the palette must degrade gracefully.
- **No external dependencies for fonts or images.** The TUI runs in whatever terminal the user opens. Nerd Font glyphs are tempting but excluded — the system should work in a plain terminal.
- **Width budget per panel** at full screen: ~30 cols for narrow panels (today, feed, threads, pulse), ~60 cols for journal. Design at those widths.

---

## 13. The feeling we're after

If a friend looks over the user's shoulder, they should think:

> *"What's that? It looks like what someone's mind looks like."*

Not:

> *"What's that, a system monitor?"*

Not:

> *"What's that, a chat app?"*

`btop` is the inspiration for *structure*. The feeling is closer to a well-kept journal with live margins — a workshop, not a console.

---

*Design Document v0.1. Pairs with CHARTER.md.*
