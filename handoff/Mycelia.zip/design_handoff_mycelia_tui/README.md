# Handoff: mycelia — TUI workspace

## Overview

`mycelia` is a terminal-user-interface (TUI) for a personal thinking environment — tasks, journal, AI conversations, and an activity feed, organized into a single dense workspace. This handoff covers the **visual and interaction design** for the primary workspace screen plus the secondary thread view. Pair with `source-brief/DESIGN.md` for the full design rationale and `CHARTER.md` (not included) for system intent.

The user spends ~95% of their time on the workspace. The thread view replaces it temporarily when an AI conversation is open.

---

## About the Design Files

The files in `prototype/` are **design references created in HTML/React** running in a browser. They are **not the implementation** — `mycelia` is a TUI that runs in a real terminal emulator.

The HTML prototype is a high-fidelity *visual + interaction* simulation. It uses real Unicode box-drawing, sparkline, and block characters; a real monospace font; teal HUD-style accent glow; and the same keyboard model the TUI should expose. Treat it as the spec for what the TUI should look and feel like.

**Your task** is to implement `mycelia`'s TUI in the appropriate terminal framework. Suggested choices (pick one that fits your stack):

| Language | Framework | Notes |
|---|---|---|
| Rust | [ratatui](https://ratatui.rs/) | Mature, fast, expressive layout primitives; good fit |
| Go | [bubbletea](https://github.com/charmbracelet/bubbletea) | Elm-style; pairs with `lipgloss` for styling |
| Python | [Textual](https://textual.textualize.io/) | CSS-like styling, web-style components, fastest to prototype |
| Zig/C++ | [notcurses](https://github.com/dankamongmen/notcurses) | Lowest level; best when squeezing every cell matters |

The colors, glyphs, spacing, panel structure, command grammar, and keyboard map below are framework-agnostic. The browser prototype is for visual reference and interaction validation, not for shipping.

---

## Fidelity

**High-fidelity.** Colors, glyphs, panel layout, command grammar, and keyboard map are final. Recreate the structure pixel-for-pixel (or cell-for-cell in TUI terms). Per the design brief, the TUI is **monospace-only**, **256-color terminal floor** with **truecolor as the target**, and must **degrade gracefully** to a 16-color palette where the user's terminal can't render the full palette.

---

## Screens / Views

### 1. Workspace (primary, ~95% of time)

The default screen. A 3-column × 2-row grid plus a top status bar, a bottom vitals strip, and a command bar.

#### Layout

```
┌─────────────────────────── status bar ────────────────────────────┐
│ ┌─ today ────────┐ ┌─ journal ──────────────────┐ ┌─ feed ──────┐ │
│ │  task list     │ │  today's entry             │ │  activity   │ │
│ │                │ │                            │ │  dashboard  │ │
│ ├─ threads ──────┤ │                            │ ├─ pulse ─────┤ │
│ │  AI threads    │ │                            │ │  sparklines │ │
│ │                │ │                            │ │  + bars     │ │
│ └────────────────┘ └────────────────────────────┘ └─────────────┘ │
├────────────────────── vitals strip ───────────────────────────────┤
│ ❯ command input                                          AI: read │
└───────────────────────────────────────────────────────────────────┘
```

#### Grid

- **Columns**: 24fr / 48fr / 28fr (left / center / right). At 120 cols this works out to roughly 28 / 56 / 32 character cells.
- **Rows**: 50fr / 50fr inside the workspace area.
- **Cell assignments**:
  - col 1, row 1 → `today`
  - col 1, row 2 → `threads`
  - col 2, rows 1–2 → `journal` (spans both rows)
  - col 3, row 1 → `feed`
  - col 3, row 2 → `pulse`
- **Top status bar**: 1 row tall, full width.
- **Vitals strip**: 1 row tall, full width, between workspace and command bar.
- **Command bar**: 2 rows tall, full width.

#### Responsive behavior

The TUI must remain usable at 80×24. Between 100 and 120 cols, drop `threads` and `pulse` (move them behind keyboard shortcuts `t` and `p`), keeping `today` / `journal` / `feed`. Below 100 cols, collapse to a single full-screen panel with a tab strip and the command bar.

### 2. Thread view

Replaces the workspace when an AI thread is opened.

Two-column layout: a narrow **thread metadata** panel on the left (28%) showing model, profile, tokens, cost, started-at, key bindings; and a wide **conversation** panel on the right (72%) showing user/AI turns and tool calls. The status bar at top and command bar at bottom persist.

In thread view, the command bar's mode changes — typing plain text **sends to the thread** rather than appending to the journal. `/` slash commands and `!` shell still work normally. `Esc Esc` returns to the workspace.

---

## Components

### Panel (atomic chrome unit)

Every section of the UI is a `Panel`. A panel has:

- **Light-rounded box-drawing border**: `╭─╮ │ │ ╰─╯`. Never use heavy box-drawing or square corners (`+---+`). Always rounded.
- **Title** in the top border at left, surrounded by short dashes: `╭─ today ─` — title is in the panel's color (border color when unfocused, accent when focused).
- **Optional count indicator** in the top-right of the border: `─ 7 ─╮` — used for panels with countable items (active tasks, unread threads, pending reviews).
- **Optional focus glyph** in the title when focused: `╭─ today ◉ ─`.
- **Body** with 1 char of padding from the border on left and right, 1 line of padding top and bottom.
- **Focus state**: when focused, the border color shifts from `#1c2a28` (border-muted) to `#7fd1c4` (accent), and the border gets a subtle text-shadow glow.

In the HTML prototype, panels are drawn by emitting the full set of `─│╭╮╰╯` characters in a `<pre>` (sized to the panel's measured cell dimensions); a TUI library does this natively via its `Block` / `Border` widget — use the rounded variant.

### Task line (in `today` panel)

```
 ●  Buy oat milk                                                    tue
```

| Element | Width | Glyphs | Color |
|---|---|---|---|
| Status glyph | 2 chars | `○` open · `◐` in-progress · `●` done · `!` overdue · `~` deferred | accent for open/in-progress; muted for done; strong-accent for overdue |
| Title | flex | task body, truncated with `…` if too long | strong-accent if overdue; muted+strikethrough if done; default otherwise |
| Tag | optional | `#errands`, `#mycelia`, etc. | muted | **Hidden in narrow `today` column** to give the title room. Tags only show in wider task views (`/todo list`). |
| When | 6 chars max | `tue`, `5/22`, `mon`, `today`, or `·` for no-date | muted; strong-accent if overdue | Right-aligned, tabular numerals. |

Selected task gets a 7% accent-alpha background.

### Feed dashboard (in `feed` panel) — *visual, not log-style*

The feed panel is **not** a chronological text log. It's three stacked sections, now live:

1. **`── activity, today ──`** — counts by kind, as gradient bar charts (same `GradBar` meter as Pulse's tag bars, `glow={false}`):
   ```
     ✓  TASK  ████████████████████  5
     ◆  AI    ███████████████       4
     ✎  NOTE  ████████████          3
     ↕  SYNC  ████████              2
     !  ERR   ████                  1
   ```
   - Glyph (kind icon, 1.2ch, in kind color)
   - Name (uppercase, 11px, muted)
   - Bar: a vertically-gradient-filled meter (dim→accent left to right) with a fractional ⅛-block tail cell, not a flat single-color bar
   - Count (tabular numerals)
   - Kind colors: `task/sync/ai → accent palette`, `note/err → warm palette`

2. **`── event rate ──`** — replaces the old static hourly density heatmap. A **live scrolling braille area graph** (3 rows tall, `accent` palette) of the event rate, continuously fed a new sample every ~900ms so the panel always has ambient motion, even with no real new events.

3. **`── latest ──`** — the 3 most-recent events as **compressed** single-line entries: `● kind  short-text  hh:mm`. No multi-line log. Unchanged from the original brief.

### Pulse board (in `pulse` panel)

Now a live btop-style monitor — three `MetricGraph` units, each a labelled headline value + delta + a **scrolling braille area graph** (not a static block-sparkline), followed by the tag breakdown:

1. **Metric graphs**:
   ```
   WORDS / MIN                                          271 wd  ▴12
   ⠀⠀⠀⠀⣀⣴⣾⣿⣿⣶⣤⡀⠀⠀⠀⠀⠀⠀⣠⣴⣾⣿⣶⣄⠀⠀⠀⠀⠀⠀⠀⠀
   TASKS / HR                                              5  ▾1
   ⠀⠀⢀⣠⣴⣶⣾⣿⣿⣶⣦⣄⡀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣶⣾⡿⠿⠶⣄⠀⠀⠀
   AI CALLS / HR                                          12  ▴3
   ⠀⠀⠀⠀⢀⣠⣴⣶⣿⣿⣷⣶⣄⡀⠀⠀⠀⠀⠀⠀⠀⢀⣠⣴⣶⣿⡿⠶⣄⠀⠀⠀
   ```
   - Label (11px, uppercase, dim, letter-spaced)
   - Current value (strong-fg, tabular numerals) + delta arrow (`▴`/`▾`, comparing to ~7 samples ago)
   - Graph: a **braille area graph** (2×4 dots/cell), area-filled with a 3-stop vertical gradient (dim at the bottom, hottest/brightest at the peak), scrolling left as new samples arrive every 600–1200ms depending on the metric. `words/min` uses the warm palette (teal→gold→red-ish per hue); `tasks/hr` and `ai calls/hr` use the accent palette.
   - This replaces the old flat-color block-character (`▁▂▃▄▅▆▇█`) sparkline row entirely.

2. **`── tasks touched by tag ──`** — horizontal gradient bars per tag (unchanged structurally, now rendered with `GradBar` instead of raw `█` repeats):
   ```
   ████████████████  #mycelia    12
   ███████████       #writing     8
   ███████           #research    5
   ████              #errands     3
   ███               #admin       2
   ```

> The `── words by hour ──` histogram from the original spec was dropped in favor of the live `words/min` metric graph above — it covers the same information with continuous motion instead of a static per-hour bar chart.

### Braille area graphs & gradient meters (new primitive, `charts.jsx`)

The core visual upgrade across Pulse, Feed, and Vitals is a shared engine, not a per-panel hack:

- **`BrailleGraph`** — renders a numeric sample array as a scrolling area graph using Unicode braille characters (U+2800 block), 2 dot-columns and up to 4 dot-rows per character cell for sub-cell vertical resolution. Each row is colored by a 3-stop gradient (`grad3`) sampled by vertical position, so the graph is dim near the baseline and brightest at the top — mimics `btop`'s CPU/memory graph look.
- **`GradBar`** — a horizontal meter: full gradient-colored `█` cells, one fractional-eighth `▏▎▍▌▋▊▉` tail cell for sub-cell precision, then a dim `░` track for the remainder. Used for Focus (Vitals), tag bars (Pulse), and kind bars (Feed).
- **`useStream`** — a small hook producing a mean-reverting random walk in a fixed-length ring buffer on an interval, giving every graph continuous, self-sustaining motion without needing real backend data. **A TUI implementation should replace this with real polling/push data** from the daemon at a similar cadence (roughly 0.6–1.6s per tick) — the visual spec (gradient, braille density, scroll behavior) should carry over unchanged.
- Palettes read live off the CSS custom properties (`--accent`, `--accent-dim`, `--accent-strong`, `--warning`, `--danger`), so they automatically follow the Accent-hue Tweak.

### Active-thread block + thread item (in `threads` panel)

The **first active thread** renders as a richer 2-line block:

```
 ●  weekly review        ⠹  claude    2m
    ctx ████░░░░░░░░░░░░  14.2k / 200k     $0.21
```

- Line 1: filled dot (unread, glowing accent), title (strong-fg, accent-glow), spinner braille glyph, model (muted-2), age (muted, right).
- Line 2: `ctx` label, used cells (accent, glow), unused cells (border-muted), `used / max` token count, cost (right-aligned).
- A 1px dashed border-bottom separates it from the rest of the list.

The remaining threads render as compact single rows:
```
 ○  refactor inbox tagging   kimi    23m
```

Glyph (filled `●` if updated since last viewed, empty `○` otherwise), title (truncates), model, age.

### Sparkline / spinner

- **Sparkline glyph set**: `▁▂▃▄▅▆▇█` (Unicode block lower 1/8 through full block). Use 16–18 cells for "today" sparklines.
- **Spinner**: braille frames `⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏`, ~110ms per frame. Only used to indicate an in-flight AI call.

### Status bar (top, 1 row)

```
╭─ mycelia ─── review: 3 ──── 2026-05-19 Tue ─── ↑ synced 2m ago ─╮
```

- Left: `╭─ mycelia ─` (app name in accent, glow)
- Optional: `── review: N ──` if review queue has pending items (warning color for the number)
- Center: `─── YYYY-MM-DD Day ───` (muted)
- Right: `── glyph status ─╮` (sync glyph + text; colors below)

Sync glyphs:
- `↑ synced Nm ago` — success
- `↻ syncing…` — accent
- `⚠ conflict pending` — warning
- `· offline` — muted

### Vitals bar (between workspace and command bar, 1 row, dashed top border)

A horizontal strip of live metrics laid out as `KEY value` pairs separated by gaps:

```
FOCUS ████████████████░░ 74%  FLOW ⣀⣠⣴⣾⣿⣷⣄⣀⣠⣤⣾⣿  THIS HOUR 218 wd  TOK/S 142 ⠹                    UPTIME 3h 24m
```

- `FOCUS` — a live `GradBar` gauge (warm gradient, continuously drifting toward the real focus % rather than a static readout).
- `FLOW` — a compact **live braille area graph** (1 row tall, ~16 cells wide) of recent attention rhythm — same scrolling mechanism as Pulse's graphs, just shorter. Replaces the earlier static block-sparkline.
- `THIS HOUR` — words written in the current hour.
- `TOK/S` — current AI throughput, ticking live; pairs with the spinner glyph.
- `UPTIME` — pushed to the far right (`margin-left: auto`).

Keys are uppercase, 10px, letter-spaced; values are tabular numerals.

### Command bar (bottom, 2 rows)

```
 ❯ type to journal · /command · ?ask · !shell                              AI: read
```

- **Prompt glyph** `❯` at the far left, accent + glow, bold weight.
- **Input area** consuming the middle; caret color is `accent`.
- **Ghost text** for slash-command completion: as soon as input starts with `/`, render the most likely completion in muted color past the cursor. `Tab` accepts it.
- **Mode indicator** at the far right: `AI: read` / `AI: draft` / `AI: act`. Colors:
  - `read` → muted-2
  - `draft` → warning
  - `act` → danger
- 1px solid border on top, full width.
- The bar is **modal by syntax, not by toggle**. See "Command grammar" below.

---

## Interactions & Behavior

### Command grammar

The user types into the command bar and presses Enter. Parse by first character:

| Prefix | Behavior |
|---|---|
| (none — plain text) | Append to today's journal entry. |
| `/` | Slash command. See list below. |
| `?` | Ask the active AI thread (or start a new `read`-profile thread if none active). |
| `!` | Shell passthrough — execute in the repo `cwd`. Output streams into the feed as a `sync` (or `err`) item. |

Slash commands (minimum set):

```
/todo add <text>        — add a task; parse #tag, due:fri, proj:xxx
/todo done <id|title>   — complete
/todo list              — open a task-focused view
/note new <title>       — create a note, open in journal panel for editing
/note find <query>      — search notes; results to feed
/journal yesterday      — open a relative-day journal
/in <text>              — append to today's inbox
/ask <prompt>           — claude, read profile, new thread
/think <prompt>         — same as /ask but enters thread view immediately
/draft <prompt>         — claude, draft profile → drafts/
/tag <selector>         — kimi-batch tag operation
/triage inbox           — kimi pre-process, claude review, results to review queue
/agent <prompt>         — full-tool run (act profile); CONFIRMATION REQUIRED
/review                 — open review queue
/sync                   — manual sync now
/find <query>           — open search overlay
/help                   — help modal
```

Provide a `?` help modal at any time.

### Ghost-completion behavior

Only completes when input starts with `/`. Match the longest registered command that starts with the input. Render the completion as `muted` text past the cursor. `Tab` accepts (replaces input with completion).

### Feedback toasts

After any command, surface a 1-line transient toast just above the command bar (centered-left, 2.2s duration). Color by kind: `success` for ok, `accent` for info, `warning` for warn, `danger` for err. Prefix with `▸`.

### Panel focus

One panel is always either focused or the command bar is. Cycle order: `today → journal → feed → threads → pulse → today`.

| Key | Action |
|---|---|
| `Tab` | Next panel |
| `Shift-Tab` | Previous panel |
| `Ctrl-1..5` | Jump to panel by index |
| `Esc` | Return focus to the command bar |

Hide skipped panels (`threads`/`pulse` toggled off) from the cycle. When a panel is focused, route keyboard input to it (see panel-specific keys below).

### Task panel keys (`today` focused)

| Key | Action |
|---|---|
| `j` / `ArrowDown` | Move selection down |
| `k` / `ArrowUp` | Move selection up |
| `Enter` | Open task detail view (not implemented in prototype) |
| `Space` | Toggle status (open ↔ in-progress) |
| `x` | Mark done |
| `d` | Set due date |
| `e` | Edit task body |

### Threads panel keys

| Key | Action |
|---|---|
| `j` / `k` | Navigate |
| `Enter` | Open thread (switches to thread view) |
| `n` | New thread |
| `d` | Archive |

### Thread-view keys

| Key | Action |
|---|---|
| `Esc Esc` | Back to workspace (single `Esc` also accepted) |
| `Ctrl-S` | Save thread as note in `notes/` |
| `r` | Change profile for the next message |

### Journal panel — light vim split

The journal panel is **the only modal panel**. `i` enters insert mode, `o` opens a new line below in insert mode, `Esc` leaves insert mode. Outside the journal the TUI is modeless.

### Global keys

| Key | Action |
|---|---|
| `?` | Help modal |
| `Ctrl-C` | Cancel current operation; second press within 1s quits |
| `Ctrl-R` | Open review queue |

### Animation / motion

The original brief limited motion to three cases (streaming AI text, the braille spinner, and instant sparkline updates). **This was revised** — the user asked for a more "btop pulse"-like feel, with continuous live motion rather than a mostly-static text UI. Current scope:

1. **Streaming AI text** — token-by-token append in the thread view; cursor visibly advances. (Not implemented in this prototype — user opted out of the live stream demo.)
2. **Progress glyphs** — braille spinner, ~110ms per frame, slow and steady.
3. **Live braille area graphs** — Pulse's 3 metric graphs, Feed's event-rate graph, and the Vitals `FLOW` strip all continuously stream new samples (every 600–1600ms per metric) and scroll left, with no easing — each tick is just the next frame, but the *effect* is constant, ambient motion, closer to `btop` than a static dashboard.
4. **Live gradient meters** — the Vitals `FOCUS` gauge and `TOK/S` value tick continuously rather than reading a fixed snapshot.

Panel *chrome* still updates instantly — focus border changes, modal open/close, and toasts have no easing/fade. The motion is scoped to the telemetry graphs, not the UI structure.

---

## State Management

State lives in the daemon (out of scope for this handoff), but the TUI needs:

- **`focus`**: `'command'` or one of the panel keys (`today`, `journal`, `feed`, `threads`, `pulse`).
- **`selectedTaskId`**: which task in the `today` panel is highlighted.
- **`openThreadId`**: when set, render the thread view instead of the workspace.
- **`commandInput`**: current command bar text.
- **`commandGhost`**: derived from `commandInput` (longest-prefix slash command).
- **`mode` / `aiProfile`**: `'read' | 'draft' | 'act'` — drives the right-side badge color.
- **`feed`**: prepend-only stream of events; cap at 30 in-memory for the dashboard.
- **`tasks` / `journal` / `threads` / `pulse`**: read from the daemon's data layer.
- **`reviewCount`**: number of pending review-queue items; shown in the status bar when nonzero.

State transitions are driven by:

- Keyboard events (focus shift, panel-specific actions, command submit).
- Daemon push events (new feed item, thread update, sync state change).
- Command submission (parse → dispatch).

### Empty states

Every panel needs an empty state — a muted single-line message, no illustration:

- `today` (no tasks): `nothing due. press / to add.`
- `journal` (no entry today): `start typing to begin today's entry.`
- `feed` (nothing recent): `quiet here. activity will appear.`
- `threads` (none active): `no active threads. /ask to start one.`
- `pulse` (no data yet): labels with `—` instead of sparklines.
- `review queue` (empty): `nothing to review.`

---

## Design Tokens

### Colors (dark theme, primary)

| Token | Hex | Use |
|---|---|---|
| `--bg` | `#07100f` | Background (terminal default; never set on whole UI in real TUI) |
| `--bg-soft` | `#0c1716` | Subtle panel-tint, journal inline code |
| `--fg` | `#c6d4d1` | Default foreground |
| `--fg-strong` | `#e7f1ee` | Emphasized text (titles, current sparkline values) |
| `--muted` | `#4a5c5a` | Borders, dim text, timestamps |
| `--muted-2` | `#6a7d7a` | Secondary text (tags, kind labels) |
| `--border` | `#1c2a28` | Panel borders when unfocused |
| `--accent-dim` | `#4a8a82` | Sparkline base, focused-panel border on dim terminals |
| `--accent` | `#7fd1c4` | Focused panel borders, prompt glyph, primary AI color, glow source |
| `--accent-strong` | `#9be9da` | Overdue, errors, "act" profile, urgent attention |
| `--accent-glow` | `rgba(127, 209, 196, .55)` | text-shadow glow on focused border, accent text |
| `--success` | `#6ea679` | Completed tasks, successful sync, "task" kind, "up" delta |
| `--warning` | `#c9a96a` | Draft profile, pending review count, sync warnings, "note" kind |
| `--danger` | `#c46b6b` | Act profile, errors, conflicts, "err" kind |

The whole palette must sit comfortably with the terminal's existing 16-color scheme. For 16-color terminals, map: `accent → cyan`, `accent-strong → bright cyan`, `success → green`, `warning → yellow`, `danger → red`, `muted/border → bright black`, `fg → white`, `fg-strong → bright white`.

### Accent variants (Tweakable in prototype, but ship teal as default)

| Hue | Dim | Main | Strong |
|---|---|---|---|
| Teal (default) | `#4a8a82` | `#7fd1c4` | `#9be9da` |
| Gold | `#8a7340` | `#d4b56a` | `#ecd28a` |
| Lilac | `#6b6a8a` | `#a8a6d8` | `#c4c2ee` |
| Olive | `#7a8a4a` | `#c4d47a` | `#dcec98` |

Match the `accent-glow` rgba to the chosen hue at ~55% alpha.

### Typography

Monospace only. The prototype defaults to **JetBrains Mono** (weights 300/400/500/600). Acceptable alternates exposed in the Tweaks panel:

- JetBrains Mono (default)
- IBM Plex Mono (warmer)
- Share Tech Mono (HUD/CRT feel)
- Space Mono (rounded, technical)

In a real terminal, the choice is the user's terminal font — the design must work with any standard monospace.

- Default font size: 14px (web). In a terminal, this is whatever cell size the user has.
- Line height: 20px on web (1.43 ratio); in a TUI, exactly 1 cell per row.
- Microsizes for chrome labels: 10–11px (uppercase kind labels, "today by hour" dividers). In a real TUI, these are simply uppercase + slightly muted; size doesn't change.

### Spacing

In a TUI, all spacing is in **cells** (character widths) and **rows** (line heights). Translation from the prototype:

| CSS | Cells |
|---|---|
| `1ch` | 1 cell |
| `var(--ch)` | 1 cell |
| `var(--lh)` | 1 row |
| Panel body padding | 1 row top, 1 cell left/right, 1 row bottom |
| Inter-row gap inside panel | 1 row |

### Box-drawing & glyph catalogue

| Use | Glyph |
|---|---|
| Panel corners (light, rounded) | `╭ ╮ ╰ ╯` |
| Panel edges | `─ │` |
| Junctions | `├ ┤ ┬ ┴ ┼` (use sparingly) |
| Task: open | `○` |
| Task: in-progress | `◐` |
| Task: done | `●` (faded color) |
| Task: overdue | `!` |
| Task: deferred | `~` |
| Thread: unread | `●` (filled, glow) |
| Thread: read | `○` |
| Sync: synced | `↑` |
| Sync: syncing | `↻` |
| Sync: conflict | `⚠` |
| Sync: offline | `·` |
| Confirmed action | `✓` |
| Removed | `✗` |
| Spinner | `⠋ ⠙ ⠹ ⠸ ⠼ ⠴ ⠦ ⠧ ⠇ ⠏` |
| Sparkline | `▁ ▂ ▃ ▄ ▅ ▆ ▇ █` |
| Histogram filled / empty | `█ ░` |
| Heatmap event cell | `■` |
| Heatmap empty cell | `·` |
| Focus indicator | `◉` |
| Prompt | `❯` |
| AI marker | `◆` |
| Note marker | `✎` |
| Sync marker (in feed) | `↕` |
| Toast prefix | `▸` |
| Delta up / down | `▴` / `▾` |

**Never use Nerd Font glyphs** — must work in a plain terminal. The brief excludes them.

### Effects (HUD feel)

The prototype uses these CSS-only effects that you should approximate in TUI:

- **Subtle text-shadow glow** on accent text (focused panel borders, prompt, sparklines): `text-shadow: 0 0 6px var(--accent-glow)`. In a TUI: this is achieved by terminal-rendering at full saturation; pair muted dim regions around accent regions to create implicit contrast.
- **Faint CRT scanline overlay** (web-only): 1px repeating gradient, `mix-blend-mode: screen`. Skip in TUI.
- **Radial vignette**: only on web. Skip in TUI.

---

## Assets

No image assets. The full UI is composed of monospace characters, Unicode box-drawing, block, and braille glyphs.

Fonts (web prototype only): loaded from Google Fonts:
- `JetBrains Mono` (300/400/500/600)
- `IBM Plex Mono` (300/400/500/600)
- `Share Tech Mono`
- `Space Mono` (400/700)

In the real TUI, the user's terminal font is used.

---

## Files

```
design_handoff_mycelia_tui/
├── README.md                       — this document
├── prototype/                      — HTML/React visual reference
│   ├── mycelia.html                — entry point; loads React + Babel + the JSX files; defines all CSS
│   ├── app.jsx                     — main App component; routing (workspace vs thread view), keyboard handlers, command-bar dispatch, Tweaks
│   ├── charts.jsx                  — live-graph engine: braille area-graph renderer, gradient math (grad3), the useStream live-data hook, BrailleGraph / GradBar / MetricGraph components. Load order: data.jsx → charts.jsx → components.jsx
│   ├── components.jsx              — Panel, TaskLine, FeedBoard, PulseBoard, VitalsBar, StatusBar, CommandBar, ThreadItem, ActiveThreadBlock, Spinner, JournalDoc, …
│   ├── data.jsx                    — SEED.* — tasks, journal, feed, threads, pulse, vitals, thread-view fixtures
│   ├── thread-view.jsx             — Thread view (2-column metadata + conversation)
│   └── tweaks-panel.jsx            — Tweaks shell (visual-only; not part of the real TUI design)
└── source-brief/
    └── DESIGN.md                   — original design brief by the user (authoritative source of truth)
```

### How to view the prototype

Open `prototype/mycelia.html` in a browser. The UI runs locally — no build step. The Tweaks panel (bottom-right of the page) lets you toggle accent hue, monospace family, threads/pulse panels, and AI profile to see how the design responds.

The prototype runs in a browser to make sharing easy; the **real implementation runs in a terminal**.

---

## Anything that overrode the brief

- The **feed panel** was originally specced as a chronological event log. After feedback, it was redesigned as a visual dashboard (gradient kind-count bars + a live scrolling event-rate graph + 3 latest events) to fit the brief's "btop-density" mood better. The original-style chronological feed is still valuable in a dedicated view — consider adding it as `/feed` or behind a `more` action on the dashboard.\n- **Pulse, Feed, and Vitals were upgraded from static sparklines/heatmaps to live, continuously-scrolling braille area graphs** (btop-style), per explicit user request. This is the biggest visual change since the original brief — see \"Braille area graphs & gradient meters\" above. A terminal implementation needs a real polling/tick loop (or the daemon pushing samples) to drive this; it's not just a rendering concern.
- A **vitals strip** between the workspace and command bar was added to surface live metrics (focus gauge, flow, words/hour, tok/s, uptime) — not in the original brief but consistent with the "system is alive" feeling specified.
- An **active-thread block** within the `threads` panel was added — a richer 2-line render of the currently-active thread showing context-window usage as a bar and cost. The rest of the threads list keeps the brief's compact one-line format.

These additions are recommendations; treat them as enhancements rather than required scope.

---

## Open questions for engineering

- **Daemon protocol**: this handoff only describes the TUI side. The `mycelia` daemon (CHARTER.md) owns task storage, journal files, AI calls, sync, review queue. Define the IPC contract before implementation.
- **Light theme**: dark is primary. A light variant is owed by the brief — define hex tokens in parallel with the dark tokens above.
- **High-contrast 16-color theme**: required by the brief for accessibility. Map the palette to terminal colors 0–15 only.
- **Mouse support**: bonus, not required. If implemented: clicks change panel focus, scroll wheel scrolls within `feed` / `journal`.

---

*Spec compiled from DESIGN.md + prototype iteration. Pairs with the CHARTER.md (not included here) for system intent.*
