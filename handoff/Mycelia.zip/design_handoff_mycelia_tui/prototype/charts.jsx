// charts.jsx — btop-style live chart engine for mycelia
// Braille area graphs (2×4 dots/cell), live data streams, gradient meters.

const { useState: useStateC, useEffect: useEffectC, useRef: useRefC,
        useLayoutEffect: useLayoutEffectC, useMemo: useMemoC } = React;

// ─────────────────────────────────────────────────────────────────────────────
// math + color helpers

function clampN(v, lo, hi) { return Math.max(lo, Math.min(hi, v)); }

function hexToRgb(h) {
  h = (h || '#000').trim().replace('#', '');
  if (h.length === 3) h = h.split('').map(c => c + c).join('');
  return [parseInt(h.slice(0, 2), 16) || 0, parseInt(h.slice(2, 4), 16) || 0, parseInt(h.slice(4, 6), 16) || 0];
}
function rgbToHex(r) {
  return '#' + r.map(x => clampN(Math.round(x), 0, 255).toString(16).padStart(2, '0')).join('');
}
function mix(a, b, t) { return a + (b - a) * t; }

// 3-stop gradient: t=0 → stops[0], t=.5 → stops[1], t=1 → stops[2]
function grad3(stops, t) {
  const [a, b, c] = stops.map(hexToRgb);
  t = clampN(t, 0, 1);
  let out;
  if (t <= 0.5) { const tt = t / 0.5; out = a.map((v, i) => mix(v, b[i], tt)); }
  else { const tt = (t - 0.5) / 0.5; out = b.map((v, i) => mix(v, c[i], tt)); }
  return rgbToHex(out);
}

// read live accent stops off :root so it tracks the Accent tweak
function readPalette(name) {
  const cs = getComputedStyle(document.documentElement);
  const g = (k, fb) => (cs.getPropertyValue(k).trim() || fb);
  if (name === 'warm') return [g('--accent-dim', '#4a8a82'), g('--warning', '#c9a96a'), g('--danger', '#c46b6b')];
  return [g('--accent-dim', '#4a8a82'), g('--accent', '#7fd1c4'), g('--accent-strong', '#9be9da')];
}

// ─────────────────────────────────────────────────────────────────────────────
// Braille area graph
// Each cell is a 2-wide × 4-tall dot matrix. We fill from the bottom up to the
// sample height — newest sample on the right, so the line scrolls left over time.

const BR_LEFT_UP  = [0x40, 0x04, 0x02, 0x01]; // bottom→top, left dot column
const BR_RIGHT_UP = [0x80, 0x20, 0x10, 0x08]; // bottom→top, right dot column

function brailleArea(norm, width, height) {
  const cols = width * 2;
  let data = norm.slice(-cols);
  while (data.length < cols) data.unshift(0);
  const totalRows = height * 4;
  const grid = Array.from({ length: height }, () => new Array(width).fill(0x2800));
  for (let cc = 0; cc < width; cc++) {
    for (let side = 0; side < 2; side++) {
      const v = data[cc * 2 + side];
      if (v == null) continue;
      const level = Math.round(clampN(v, 0, 1) * totalRows);
      const bits = side === 0 ? BR_LEFT_UP : BR_RIGHT_UP;
      for (let dr = 0; dr < level; dr++) {
        const rowFromBottom = Math.floor(dr / 4);
        const charRow = height - 1 - rowFromBottom;
        if (charRow < 0) break;
        grid[charRow][cc] |= bits[dr % 4];
      }
    }
  }
  return grid.map(row => row.map(c => String.fromCharCode(c)).join(''));
}

// ─────────────────────────────────────────────────────────────────────────────
// measure how many character columns fit in a container

function useCharCols(ref, min = 8, override) {
  const [cols, setCols] = useStateC(override || min);
  useLayoutEffectC(() => {
    if (override) { setCols(override); return; }
    const el = ref.current;
    if (!el) return;
    const upd = () => {
      const ch = parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--ch')) || 8.4;
      setCols(Math.max(min, Math.floor(el.clientWidth / ch)));
    };
    upd();
    const ro = new ResizeObserver(upd); ro.observe(el);
    const mo = new MutationObserver(upd);
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['style'] });
    return () => { ro.disconnect(); mo.disconnect(); };
  }, [override]);
  return cols;
}

// ─────────────────────────────────────────────────────────────────────────────
// live data stream — mean-reverting random walk in a ring buffer

function seedWalk(n, base, vary, min, max) {
  const a = []; let v = base;
  for (let i = 0; i < n; i++) {
    v += (Math.random() - 0.5) * vary - (v - base) * 0.08;
    v = clampN(v, min, max);
    a.push(v);
  }
  return a;
}

function useStream({ base = 100, vary = 60, min = 0, max = 400, period = 850, len = 140 }) {
  const [samples, setSamples] = useStateC(() => seedWalk(len, base, vary, min, max));
  const vRef = useRefC(samples[samples.length - 1]);
  useEffectC(() => {
    const id = setInterval(() => {
      let v = vRef.current;
      v += (Math.random() - 0.5) * vary - (v - base) * 0.08;
      v = clampN(v, min, max);
      vRef.current = v;
      setSamples(s => {
        const n = s.length >= len ? s.slice(1) : s.slice();
        n.push(v);
        return n;
      });
    }, period);
    return () => clearInterval(id);
  }, [base, vary, min, max, period, len]);
  return samples;
}

// ─────────────────────────────────────────────────────────────────────────────
// BrailleGraph — renders a stream as a scrolling, gradient-filled area graph

function BrailleGraph({ samples, height = 3, palette = 'accent', glow = true, cols: colsOverride, scaleMax }) {
  const ref = useRefC(null);
  const cols = useCharCols(ref, 8, colsOverride);
  const max = scaleMax != null ? scaleMax : Math.max(1e-6, ...samples) * 1.18;
  const norm = samples.map(v => clampN(v / max, 0, 1));
  const rows = useMemoC(() => brailleArea(norm, Math.max(8, cols), height),
    [norm.join(','), cols, height]);
  const stops = readPalette(palette);
  return (
    <div ref={ref} className="bgraph" style={{ width: '100%', overflow: 'hidden' }}>
      {rows.map((r, i) => {
        const t = height <= 1 ? 1 : 1 - (i / (height - 1)); // top row = hottest
        const col = grad3(stops, t);
        return (
          <div key={i} style={{
            color: col,
            lineHeight: '15px',
            height: '15px',
            whiteSpace: 'pre',
            letterSpacing: 0,
            fontVariantLigatures: 'none',
            textShadow: glow && i === 0 ? `0 0 6px ${col}88` : 'none',
          }}>{r}</div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// GradBar — btop-style meter: gradient block run + 1/8 fractional tail + dim track

const EIGHTHS = ['', '▏', '▎', '▍', '▌', '▋', '▊', '▉'];

function GradBar({ pct, cells = 14, palette = 'accent', glow = true }) {
  const stops = readPalette(palette);
  const total = clampN(pct, 0, 1) * cells;
  const full = Math.floor(total);
  const fracIdx = Math.round((total - full) * 8);
  const out = [];
  let used = 0;
  for (let i = 0; i < full && i < cells; i++) {
    const t = cells <= 1 ? 1 : i / (cells - 1);
    out.push(<span key={i} style={{ color: grad3(stops, t) }}>█</span>);
    used++;
  }
  if (used < cells && fracIdx > 0) {
    const t = cells <= 1 ? 1 : used / (cells - 1);
    out.push(<span key="frac" style={{ color: grad3(stops, t) }}>{EIGHTHS[fracIdx]}</span>);
    used++;
  }
  for (let i = used; i < cells; i++) {
    out.push(<span key={'e' + i} style={{ color: 'var(--border)' }}>░</span>);
  }
  return (
    <span className="gradbar" style={{ whiteSpace: 'pre', letterSpacing: 0, textShadow: glow ? '0 0 5px var(--accent-glow)' : 'none' }}>
      {out}
    </span>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MetricGraph — labelled headline value + delta + braille graph (the Pulse unit)

function MetricGraph({ label, samples, height = 3, palette = 'accent', unit = '', decimals = 0 }) {
  const cur = samples[samples.length - 1] || 0;
  const prev = samples[Math.max(0, samples.length - 7)] || cur;
  const d = cur - prev;
  const dir = d >= 0 ? 'up' : 'down';
  return (
    <div style={{ marginBottom: 'calc(var(--lh) * 0.4)' }}>
      <div className="row" style={{ minHeight: 'var(--lh)', gap: '1ch' }}>
        <span className="dim2" style={{ fontSize: 11, textTransform: 'uppercase', letterSpacing: '.05em' }}>{label}</span>
        <span className="grow"></span>
        <span className="strong" style={{ fontVariantNumeric: 'tabular-nums' }}>{cur.toFixed(decimals)}{unit}</span>
        <span className={`delta ${dir}`} style={{ minWidth: '5ch', textAlign: 'right', fontSize: 11, fontVariantNumeric: 'tabular-nums' }}>
          {dir === 'down' ? '▾' : '▴'}{Math.abs(d).toFixed(decimals)}
        </span>
      </div>
      <BrailleGraph samples={samples} height={height} palette={palette} />
    </div>
  );
}

Object.assign(window, {
  brailleArea, useStream, useCharCols, readPalette, grad3,
  BrailleGraph, GradBar, MetricGraph,
});
