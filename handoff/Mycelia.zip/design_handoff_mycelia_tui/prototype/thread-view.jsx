// thread-view.jsx — AI conversation pane

function ThreadView({ thread, onBack }) {
  return (
    <div className="threadview">
      <Panel
        title="thread"
        focused={false}
        bodyScroll
        className="thread-meta-panel"
      >
        <div className="dim2 b" style={{ marginBottom: 'var(--lh)' }}>
          {thread.title}
        </div>
        <div className="dim" style={{ marginBottom: 4 }}>model</div>
        <div className="strong" style={{ marginBottom: 'calc(var(--lh) * 0.6)' }}>{thread.model}</div>

        <div className="dim" style={{ marginBottom: 4 }}>profile</div>
        <div className="acc" style={{ marginBottom: 'calc(var(--lh) * 0.6)' }}>{thread.profile}</div>

        <div className="dim" style={{ marginBottom: 4 }}>tokens</div>
        <div className="strong" style={{ marginBottom: 'calc(var(--lh) * 0.6)' }}>{thread.tokens}</div>

        <div className="dim" style={{ marginBottom: 4 }}>cost</div>
        <div className="strong" style={{ marginBottom: 'calc(var(--lh) * 0.6)' }}>{thread.cost}</div>

        <div className="dim" style={{ marginBottom: 4 }}>started</div>
        <div className="dim2" style={{ marginBottom: 'calc(var(--lh) * 0.8)' }}>{thread.started}</div>

        <div className="dim" style={{ marginBottom: 4 }}>history</div>
        <div className="dim2">{thread.turns.filter(t => t.who !== 'tool').length} turns</div>
        <div className="dim2">{thread.turns.filter(t => t.who === 'tool').length} tool calls</div>

        <div style={{ marginTop: 'calc(var(--lh) * 1.2)', borderTop: '1px solid var(--border)', paddingTop: 'calc(var(--lh) * 0.6)' }}>
          <div className="dim" style={{ marginBottom: 4 }}>keys</div>
          <div className="row" style={{gap: '1ch'}}><span className="acc">Esc Esc</span><span className="dim2">back</span></div>
          <div className="row" style={{gap: '1ch'}}><span className="acc">Ctrl-S</span><span className="dim2">save</span></div>
          <div className="row" style={{gap: '1ch'}}><span className="acc">r</span><span className="dim2">profile</span></div>
        </div>
      </Panel>

      <Panel
        title={thread.title}
        focused={true}
        focusGlyph
        bodyScroll
        className="thread-convo-panel"
      >
        {thread.turns.map((turn, i) => {
          if (turn.who === 'tool') {
            return (
              <div key={i} className="turn tool" style={{ paddingLeft: '2ch' }}>
                <span className="toolcall">↳ tool · {turn.text}</span>
              </div>
            );
          }
          return (
            <div key={i} className={`turn ${turn.who}`} style={{ marginBottom: 'calc(var(--lh) * 0.4)' }}>
              <div className="who">{turn.who === 'user' ? '❯ you' : '◆ claude'}</div>
              <div className="body">{turn.text}</div>
            </div>
          );
        })}

        <div className="dim" style={{ marginTop: 'var(--lh)', display:'flex', gap:'1ch', alignItems:'center' }}>
          <Spinner />
          <span>writing draft…</span>
        </div>
      </Panel>
    </div>
  );
}

window.ThreadView = ThreadView;
