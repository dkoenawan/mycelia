// components.jsx — visual primitives for mycelia

const { useState, useEffect, useRef, useLayoutEffect, useMemo, useCallback } = React;

// ─────────────────────────────────────────────────────────────────────────────
// Cell-size measurement (hoisted into a shared CSS custom property `--ch`)

function useCellMeasurement(fontFamily) {
  useEffect(() => {
    let cancelled = false;
    const remeasure = () => {
      if (cancelled) return;
      const span = document.createElement('span');
      span.style.cssText =
        'position:absolute;visibility:hidden;white-space:pre;' +
        'font-family:' + fontFamily + ',ui-monospace,monospace;' +
        'font-size:var(--fs);';
      span.textContent = 'M'.repeat(200);
      document.body.appendChild(span);
      const w = span.getBoundingClientRect().width / 200;
      document.body.removeChild(span);
      document.documentElement.style.setProperty('--ch', w + 'px');
    };
    if (document.fonts && document.fonts.ready) {
      document.fonts.ready.then(remeasure);
    } else {
      remeasure();
    }
    return () => { cancelled = true; };
  }, [fontFamily]);
}

// ─────────────────────────────────────────────────────────────────────────────
// Panel — bordered region with title + optional count, drawn from real box chars

function Panel({
  title, count, focused, focusGlyph, className, bodyScroll, children,
  onClick,
}) {
  const ref = useRef(null);
  const [dims, setDims] = useState({ cols: 40, rows: 8 });

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;

    const update = () => {
      const cs = getComputedStyle(document.documentElement);
      const chRaw = cs.getPropertyValue('--ch').trim();
      const ch = parseFloat(chRaw) || 8.4;
      const lh = parseFloat(cs.getPropertyValue('--lh')) || 20;
      const cols = Math.max(8, Math.floor(el.clientWidth / ch));
      const rows = Math.max(3, Math.floor(el.clientHeight / lh));
      setDims({ cols, rows });
    };

    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);

    // re-measure on font swaps
    const mo = new MutationObserver(update);
    mo.observe(document.documentElement, { attributes: true, attributeFilter: ['style'] });

    return () => { ro.disconnect(); mo.disconnect(); };
  }, []);

  const frame = useMemo(
    () => buildFrameLines(dims.cols, dims.rows, title, count, focusGlyph, focused),
    [dims.cols, dims.rows, title, count, focusGlyph, focused]
  );

  return (
    <div
      ref={ref}
      className={`panel ${focused ? 'focused' : ''} ${className || ''}`}
      onClick={onClick}
    >
      <pre className="panel-frame">{frame.framePre}</pre>
      {/* Title overlay sits on top border row, covering the dashes behind it */}
      <div className="panel-title-overlay">
        <span className="dash">─ </span>
        <span className={`title-name ${focused ? 'focused' : ''}`}>{title}</span>
        {focusGlyph && focused ? <span className="focus-glyph"> ◉</span> : null}
        <span className="dash"> ─</span>
      </div>
      {count != null ? (
        <div className="panel-count-overlay">
          <span className="dash">─ </span>
          <span className="count-num">{count}</span>
          <span className="dash"> ─</span>
        </div>
      ) : null}
      <div className={`panel-body ${bodyScroll ? 'scroll' : ''}`}>{children}</div>
    </div>
  );
}

function buildFrameLines(cols, rows, title, count, focusGlyph, focused) {
  // top row: ╭─────────────────────────────╮
  // (title + count are drawn as positioned overlays so we don't need to bake them in here)
  const inner = cols - 2;
  const top = '╭' + '─'.repeat(Math.max(0, inner)) + '╮';
  const midSide = '│' + ' '.repeat(Math.max(0, inner)) + '│';
  const midRows = Math.max(0, rows - 2);
  const mids = Array(midRows).fill(midSide).join('\n');
  const bot = '╰' + '─'.repeat(Math.max(0, inner)) + '╯';
  return { framePre: [top, mids, bot].filter(Boolean).join('\n') };
}

// ─────────────────────────────────────────────────────────────────────────────
// Task line

const STATUS_GLYPH = {
  'open':        { glyph: '○', cls: '' },
  'in-progress': { glyph: '◐', cls: 'inprog' },
  'done':        { glyph: '●', cls: 'done' },
  'overdue':     { glyph: '!', cls: 'overdue' },
  'deferred':    { glyph: '~', cls: 'deferred' },
};

function TaskLine({ task, selected }) {
  const meta = STATUS_GLYPH[task.status] || STATUS_GLYPH.open;
  return (
    <div className={`row task ${meta.cls} ${selected ? 'selected' : ''}`}>
      <span className={`glyph ${meta.cls === 'overdue' ? 'acc-s' : meta.cls === 'done' ? 'dim' : 'acc'}`}>
        {meta.glyph}
      </span>
      <span className="title grow truncate">{task.title}</span>
      {task.tag ? <span className="tag">{task.tag}</span> : null}
      <span className="when">{task.when || '·'}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Feed item (legacy, still used inside FeedBoard's "latest" strip)

function FeedItem({ item }) {
  return (
    <div className="row feed-item">
      <span className="time">{item.time}</span>
      <span className={`kind ${item.kind}`}>{item.kind}</span>
      <span className="grow truncate">{item.text}</span>
    </div>
  );
}

// Visual feed dashboard: counts by kind, a live event-rate graph, latest events.
function FeedBoard({ feed }) {
  // counts by kind
  const counts = {};
  for (const it of feed) counts[it.kind] = (counts[it.kind] || 0) + 1;
  const KIND_ORDER = ['task', 'ai', 'note', 'sync', 'err'];
  const KIND_GLYPH = { task: '✓', ai: '◆', note: '✎', sync: '↕', err: '!' };
  const KIND_LABEL = { task: 'task', ai: 'ai', note: 'note', sync: 'sync', err: 'err' };
  const KIND_PAL   = { task: 'accent', ai: 'accent', note: 'warm', sync: 'accent', err: 'warm' };
  const maxCount = Math.max(...Object.values(counts), 1);

  // live event-rate stream — ambient motion even when nothing is happening
  const rate = useStream({ base: 6, vary: 4.5, min: 0, max: 16, period: 900, len: 160 });

  const latest = feed.slice(0, 3);

  return (
    <div>
      <div className="dim2" style={{ fontSize: 11, marginBottom: 'calc(var(--lh) * 0.2)' }}>
        ── activity, today ──
      </div>
      {KIND_ORDER.filter(k => counts[k]).map((k) => (
        <div key={k} className={`kind-bar ${k}`}>
          <span className="glyph">{KIND_GLYPH[k]}</span>
          <span className="name">{KIND_LABEL[k]}</span>
          <span className="bar" style={{ flex: '0 0 auto' }}>
            <GradBar pct={counts[k] / maxCount} cells={16} palette={KIND_PAL[k]} glow={false} />
          </span>
          <span className="count">{counts[k]}</span>
        </div>
      ))}

      <div className="pulse-divider">── event rate ──</div>
      <BrailleGraph samples={rate} height={3} palette="accent" />

      <div className="pulse-divider">── latest ──</div>
      {latest.map((it, i) => (
        <div key={i} className="mini-event">
          <span className={`dot ${it.kind}`}>●</span>
          <span className="label">{it.kind}</span>
          <span className="text">{shortText(it)}</span>
          <span className="time">{it.time}</span>
        </div>
      ))}
    </div>
  );
}

function shortText(item) {
  // strip leading symbol if present, take first 24 chars
  const t = item.text.replace(/^[\u2713\u2717+\u25d0\u25cb\u25cf↳↑↓·]\s*/, '').trim();
  return t.length > 26 ? t.slice(0, 25) + '…' : t;
}

// ─────────────────────────────────────────────────────────────────────────────
// Thread item

function ThreadItem({ thread, selected, onOpen }) {
  return (
    <div
      className={`row thread ${selected ? 'selected' : ''}`}
      onClick={onOpen}
      style={{ cursor: 'pointer' }}
    >
      <span className={`dot ${thread.unread ? 'unread' : ''}`}>{thread.dot}</span>
      <span className="grow truncate strong">{thread.title}</span>
      {thread.active ? <Spinner /> : null}
      <span className="model">{thread.model}</span>
      <span className="age">{thread.age}</span>
    </div>
  );
}

// Active thread "panel" within the threads list — a richer 2-line block
function ActiveThreadBlock({ thread }) {
  // make a tokens-used bar — pretend max is 200k, used is 14.2k
  const usedPct = 7; // ~7% of context budget
  const cap = 18;
  const filled = Math.max(1, Math.round((usedPct / 100) * cap));
  return (
    <div style={{ marginBottom: 'calc(var(--lh) * 0.4)', padding: '0 0 calc(var(--lh) * 0.2)', borderBottom: '1px dashed var(--border)' }}>
      <div className="row thread">
        <span className="dot unread">{thread.dot}</span>
        <span className="grow truncate strong acc-glow">{thread.title}</span>
        <Spinner />
        <span className="model">{thread.model}</span>
        <span className="age">{thread.age}</span>
      </div>
      <div className="row" style={{ paddingLeft: '2.5ch', gap: '1ch', fontSize: 11 }}>
        <span className="dim2">ctx</span>
        <span className="acc" style={{ textShadow: '0 0 5px var(--accent-glow)' }}>{'█'.repeat(filled)}</span>
        <span className="dim">{'░'.repeat(cap - filled)}</span>
        <span className="dim2">14.2k / 200k</span>
        <span className="dim2" style={{ marginLeft: 'auto' }}>$0.21</span>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Spinner — slow braille cycle

const SPINNER_FRAMES = ['⠋','⠙','⠹','⠸','⠼','⠴','⠦','⠧','⠇','⠏'];
function Spinner() {
  const [i, setI] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setI((x) => (x + 1) % SPINNER_FRAMES.length), 110);
    return () => clearInterval(id);
  }, []);
  return <span className="spin spinner">{SPINNER_FRAMES[i]}</span>;
}

// ─────────────────────────────────────────────────────────────────────────────
// Sparkline

function SparkRow({ row }) {
  return (
    <div className="row spark">
      <span className="label">{row.label}</span>
      <span className="line">{row.spark}</span>
      <span className="val">{row.value}</span>
      {row.delta ? (
        <span className={`delta ${row.dir || ''}`}>
          {row.dir === 'down' ? '▾' : '▴'}{row.delta}
        </span>
      ) : null}
    </div>
  );
}

// Horizontal bar made of block chars; `n` = filled cells, `cap` = total cells
function makeBar(n, cap) {
  const filled = Math.max(0, Math.min(cap, n));
  return '█'.repeat(filled) + '░'.repeat(Math.max(0, cap - filled));
}

function HistoRow({ hour, bar, val, max, cap = 14, hot }) {
  const filled = Math.round((bar / max) * cap);
  return (
    <div className="histo">
      <span className="hr">{hour}</span>
      <span className={`bar ${hot ? 'hot' : ''}`}>{makeBar(filled, cap)}</span>
      <span className="val">{val}</span>
    </div>
  );
}

function TagBar({ tag, bar, count, max, cap = 14 }) {
  const filled = Math.round((bar / max) * cap);
  return (
    <div className="tagbar">
      <span className="bar">{'█'.repeat(filled)}</span>
      <span className="name">{tag}</span>
      <span className="count">{count}</span>
    </div>
  );
}

// Rich pulse dashboard — btop-style live monitor with scrolling braille graphs
function PulseBoard({ pulse }) {
  const words = useStream({ base: 210, vary: 95, min: 20, max: 340, period: 850, len: 160 });
  const tasks = useStream({ base: 5,   vary: 3,  min: 0,  max: 12,  period: 1600, len: 160 });
  const ai    = useStream({ base: 12,  vary: 7,  min: 0,  max: 30,  period: 1200, len: 160 });

  const tagMax = Math.max(...pulse.byTag.map(t => t.bar)) || 1;

  return (
    <div>
      <MetricGraph label="words / min" samples={words} height={4} palette="warm" unit=" wd" />
      <MetricGraph label="tasks / hr"  samples={tasks} height={2} palette="accent" />
      <MetricGraph label="ai calls / hr" samples={ai}  height={2} palette="accent" />

      <div className="pulse-divider">── tasks touched by tag ──</div>
      {pulse.byTag.map((t) => (
        <div key={t.tag} className="tagbar">
          <span className="bar" style={{ flex: '0 0 auto' }}>
            <GradBar pct={t.bar / tagMax} cells={12} glow={false} />
          </span>
          <span className="name">{t.tag}</span>
          <span className="count">{t.count}</span>
        </div>
      ))}
    </div>
  );
}

// Vitals strip — live gauges
function VitalsBar({ vitals }) {
  const focus = useStream({ base: vitals.focusPct, vary: 7, min: 38, max: 97, period: 1400, len: 80 });
  const flow  = useStream({ base: 60, vary: 42, min: 4, max: 100, period: 650, len: 60 });
  const tok   = useStream({ base: vitals.tokenRate, vary: 55, min: 18, max: 320, period: 600, len: 60 });

  const focusNow = Math.round(focus[focus.length - 1] || vitals.focusPct);
  const tokNow   = Math.round(tok[tok.length - 1] || vitals.tokenRate);

  return (
    <div className="vitalsbar">
      <span className="vital">
        <span className="k">focus</span>
        <span className="gauge"><GradBar pct={focusNow / 100} cells={14} palette="warm" /></span>
        <span className="v acc">{focusNow}%</span>
      </span>
      <span className="vital">
        <span className="k">flow</span>
        <span className="gauge" style={{ display: 'inline-block', width: '16ch' }}>
          <BrailleGraph samples={flow} height={1} cols={16} glow={false} />
        </span>
      </span>
      <span className="vital">
        <span className="k">this hour</span>
        <span className="v">{vitals.thisHour} wd</span>
      </span>
      <span className="vital">
        <span className="k">tok/s</span>
        <span className="v acc">{tokNow}</span>
        <Spinner />
      </span>
      <span className="vital" style={{ marginLeft: 'auto' }}>
        <span className="k">uptime</span>
        <span className="v">{vitals.uptime}</span>
      </span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Journal doc — light markdown rendering

function JournalDoc({ journal }) {
  return (
    <div className="journal-doc">
      {journal.inbox && journal.inbox.length ? (
        <>
          <div className="dim2 b">### inbox</div>
          {journal.inbox.map((line, i) => (
            <div key={i} className="inbox-line">· {line}</div>
          ))}
          <div>&nbsp;</div>
        </>
      ) : null}
      {journal.body.map((block, i) => {
        if (block.type === 'h2') return <h2 key={i}>## {block.text}</h2>;
        if (block.type === 'h3') return <h3 key={i}>### {block.text}</h3>;
        if (block.type === 'li')
          return <div key={i} className="li">{block.text}</div>;
        return (
          <p key={i} style={{ margin: '0 0 0.6em 0' }}>
            {block.text}
            {block.cursor ? <span className="cursor">&nbsp;</span> : null}
          </p>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Status bar (top) — name | date | sync

function StatusBar({ reviewCount, syncState, dateString, glyph }) {
  // glyph map for sync
  const sync = {
    ok:       { g: '↑', text: 'synced 2m ago',     cls: 'ok' },
    syncing:  { g: '↻', text: 'syncing…',          cls: 'acc' },
    conflict: { g: '⚠', text: 'conflict pending',  cls: 'warn' },
    offline:  { g: '·', text: 'offline',           cls: 'dim2' },
  }[syncState] || { g: '↑', text: 'synced', cls: 'ok' };

  return (
    <div className="statusbar">
      <span><span className="dim">╭─ </span><span className="title-chunk b">mycelia</span><span className="dim"> ─</span></span>
      {reviewCount ? (
        <span><span className="dim">── </span><span className="warn">review: {reviewCount}</span><span className="dim"> ──</span></span>
      ) : null}
      <span className="center dim2">─── {dateString} ───</span>
      <span className="right">
        <span className="dim">── </span>
        <span className={sync.cls}>{sync.g} {sync.text}</span>
        <span className="dim"> ─╮</span>
      </span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Command bar

function CommandBar({ value, ghost, onChange, onSubmit, mode, prompt = '❯', inputRef, placeholder }) {
  const handleKey = (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      onSubmit && onSubmit(value);
    } else if (e.key === 'Tab') {
      if (ghost && ghost.length) {
        e.preventDefault();
        onChange(ghost);
      }
    }
  };

  // determine mode label
  const modeLabel = {
    read:  'AI: read',
    draft: 'AI: draft',
    act:   'AI: act',
  }[mode] || 'AI: read';

  return (
    <div className="cmdbar">
      <span className="prompt">{prompt}</span>
      <div style={{ position: 'relative', flex: '1 1 auto', display: 'flex', alignItems: 'center' }}>
        <input
          ref={inputRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={handleKey}
          placeholder={placeholder || 'type to journal · /command · ?ask · !shell'}
          spellCheck={false}
          autoComplete="off"
        />
        {ghost && ghost.length > value.length && value.length > 0 ? (
          <div style={{
            position: 'absolute',
            left: 0,
            pointerEvents: 'none',
            color: 'var(--muted)',
            whiteSpace: 'pre',
          }}>
            <span style={{ visibility: 'hidden' }}>{value}</span>
            <span>{ghost.slice(value.length)}</span>
          </div>
        ) : null}
      </div>
      <span className={`mode ${mode || 'read'}`}>{modeLabel}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Help pill

function HelpPill({ children }) {
  return <div className="help-pill">{children}</div>;
}

// Export to globals
Object.assign(window, {
  Panel, TaskLine, FeedItem, ThreadItem, ActiveThreadBlock, SparkRow, JournalDoc,
  StatusBar, CommandBar, Spinner, HelpPill, useCellMeasurement,
  HistoRow, TagBar, PulseBoard, VitalsBar, FeedBoard,
});
