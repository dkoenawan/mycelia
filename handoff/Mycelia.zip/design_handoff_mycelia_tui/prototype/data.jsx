// data.jsx — seed data for mycelia prototype
// Writer/researcher mid-week scenario, Tue 2026-05-19

const SEED_TASKS = [
  { id: 't1', status: 'overdue',     title: 'Finish draft of mycelia charter',    tag: '#mycelia',  when: 'mon' },
  { id: 't2', status: 'in-progress', title: 'Review week 20 reading notes',       tag: '#review',   when: 'today' },
  { id: 't3', status: 'open',        title: 'Reply to editor re: essay pitch',    tag: '#writing',  when: 'tue' },
  { id: 't4', status: 'open',        title: 'Read Schulman RLHF lit-review',      tag: '#research', when: 'wed' },
  { id: 't5', status: 'open',        title: 'Outline talk for Berlin meetup',     tag: '#talks',    when: 'fri' },
  { id: 't6', status: 'open',        title: 'Buy oat milk',                       tag: '#errands',  when: 'tue' },
  { id: 't7', status: 'open',        title: 'Renew library books',                tag: '#errands',  when: '' },
  { id: 't8', status: 'done',        title: 'Send invoice for april consulting',  tag: '#admin',    when: 'mon' },
];

const SEED_JOURNAL = {
  date: '2026-05-19 Tue',
  inbox: [
    'idea: a journal entry that quotes itself a year later',
    'check: did kahneman actually say that, or am I making it up',
    'follow up with R. about the residency dates',
  ],
  body: [
    { type: 'h2',   text: 'tuesday — weekly review' },
    { type: 'p',    text: 'Spent the morning re-reading last week\u2019s notes. The throughline I keep landing on is that I\u2019ve been treating tools as accessories when they\u2019re actually the workshop. The charter draft is overdue because I\u2019ve been writing around it, not into it.' },
    { type: 'p',    text: 'Three things I want to figure out today:' },
    { type: 'li',   text: 'what the daemon is responsible for, and what the TUI is responsible for' },
    { type: 'li',   text: 'whether `act` profile needs a confirmation per call or per session' },
    { type: 'li',   text: 'how the journal renders when it gets long' },
    { type: 'p',    text: 'Reading Schulman\u2019s paper again — the part about reward sparsity feels relevant to the way I\u2019m thinking about review queues. The signal here is the same: most of what the model does should be invisible until it isn\u2019t.' },
    { type: 'h3',   text: 'note to self' },
    { type: 'p',    text: 'Stop polishing the chrome. The thing that makes this work is not the borders, it\u2019s how quiet it is when nothing\u2019s happening.', cursor: true },
  ],
};

const SEED_FEED = [
  { time: '14:32', kind: 'task', text: '\u2713 sent invoice for april consulting' },
  { time: '14:30', kind: 'ai',   text: 'claude /ask \u2014 \u201cwhat have I been avoiding\u201d' },
  { time: '14:12', kind: 'note', text: 'edited  weekly-review-2026-w20' },
  { time: '14:01', kind: 'sync', text: 'pushed  3 changes to notion' },
  { time: '13:48', kind: 'task', text: '\u2713 outline mycelia charter \u00a7 daemon' },
  { time: '13:30', kind: 'ai',   text: 'kimi  /tag \u2014 17 notes \u2192 4 new tags' },
  { time: '12:54', kind: 'note', text: 'created  drafts/charter-v2.md' },
  { time: '12:30', kind: 'task', text: '+ added  Read Schulman RLHF lit-review' },
  { time: '11:58', kind: 'sync', text: 'pulled  2 changes from notion' },
  { time: '11:14', kind: 'ai',   text: 'claude /draft \u2014 berlin talk outline' },
  { time: '10:46', kind: 'task', text: '\u2713 renew domain for personal site' },
  { time: '10:22', kind: 'note', text: 'edited  reading/schulman-2024.md' },
  { time: '09:50', kind: 'err',  text: 'sync conflict on notes/inbox.md \u2014 kept local' },
  { time: '09:32', kind: 'task', text: '\u25d0 started Review week 20 reading notes' },
  { time: '09:14', kind: 'ai',   text: 'claude /ask \u2014 \u201csummarize last 5 entries\u201d' },
];

const SEED_THREADS = [
  { id: 'th1', dot: '\u25cf', unread: true,  title: 'weekly review',          model: 'claude', age: '2m',  active: true },
  { id: 'th2', dot: '\u25cf', unread: false, title: 'refactor inbox tagging', model: 'kimi',   age: '23m' },
  { id: 'th3', dot: '\u25cb', unread: false, title: 'what to read next',      model: 'claude', age: '1h' },
  { id: 'th4', dot: '\u25cb', unread: false, title: 'berlin talk outline',    model: 'claude', age: '3h' },
  { id: 'th5', dot: '\u25cb', unread: false, title: 'rephrase essay opener',  model: 'kimi',   age: '6h' },
];

const SEED_PULSE = {
  sparks: [
    { label: 'tasks', spark: '\u2582\u2584\u2583\u2585\u2588\u2586\u2582\u2585\u2587\u2588\u2585\u2583\u2582\u2584\u2585\u2583\u2581\u2582', value: 4,   delta: '+2', dir: 'up' },
    { label: 'words', spark: '\u2581\u2582\u2581\u2585\u2583\u2587\u2586\u2582\u2584\u2585\u2586\u2587\u2588\u2586\u2584\u2582\u2581\u2582', value: 812, delta: '+139', dir: 'up' },
    { label: 'ai',    spark: '\u2583\u2582\u2584\u2586\u2588\u2585\u2583\u2582\u2581\u2582\u2583\u2584\u2585\u2586\u2587\u2588\u2587\u2586', value: 17,  delta: '-3',   dir: 'down' },
  ],
  byHour: [
    { hour: '07', bar: 2,  val: 14 },
    { hour: '08', bar: 4,  val: 42 },
    { hour: '09', bar: 14, val: 286 },
    { hour: '10', bar: 7,  val: 142 },
    { hour: '11', bar: 15, val: 301 },
    { hour: '12', bar: 2,  val: 36 },
    { hour: '13', bar: 11, val: 218 },
    { hour: '14', bar: 4,  val: 84 },
  ],
  byTag: [
    { tag: '#mycelia',  count: 12, bar: 16 },
    { tag: '#writing',  count:  8, bar: 11 },
    { tag: '#research', count:  5, bar:  7 },
    { tag: '#errands',  count:  3, bar:  4 },
    { tag: '#admin',    count:  2, bar:  3 },
  ],
};

const SEED_VITALS = {
  focusPct: 74,
  flow: '\u2581\u2582\u2583\u2585\u2587\u2588\u2587\u2585\u2583\u2582\u2581\u2582\u2583\u2585\u2586\u2588',
  thisHour: 218,
  uptime: '3h 24m',
  session: '14:32',
  tokenRate: 142,
};

// thread view: the open "weekly review" thread, mid-conversation
const SEED_THREAD_VIEW = {
  id: 'th1',
  title: 'weekly review',
  model: 'claude-sonnet',
  profile: 'read',
  tokens: '14,230',
  cost: '$0.21',
  started: '2026-05-19 09:14',
  turns: [
    { who: 'user', text: 'summarize what I worked on last week. focus on the threads I left open, not what I finished.' },
    { who: 'tool', text: 'read  notes/2026-w20/*.md  (7 files, 9,412 tokens)' },
    { who: 'tool', text: 'read  journal/2026-05-1[1-7].md  (7 files)' },
    { who: 'ai',   text: 'Last week reads like two parallel threads.\n\nThe first is the charter \u2014 you started it monday, wrote three sections, then stopped on thursday at the point where you needed to decide what the daemon owns vs what the TUI owns. You haven\u2019t come back to that question yet.\n\nThe second is the reading. You opened Schulman\u2019s paper, took notes through section 3, and then pivoted to re-reading your own week-19 notes instead. The Schulman notes stop mid-sentence on tuesday.\n\nTwo smaller open threads: the berlin talk outline (drafted friday, not edited since) and the inbox triage rules (you asked kimi to propose tags, never reviewed them).' },
    { who: 'user', text: 'what have I been avoiding this week' },
    { who: 'ai',   text: 'Based on the journal\u2019s vocabulary, two things.\n\nOne, the section of the charter that asks who the system is for. You\u2019ve written around it twice \u2014 once as a question to yourself, once as a parenthetical \u2014 and not answered it.\n\nTwo, the editor\u2019s pitch reply. The task has rolled forward four days. The journal mentions it once, as \u201cthe email\u201d.\n\nNeither is urgent. Both are the kind of thing that gets easier the sooner it\u2019s touched.' },
    { who: 'user', text: 'okay. draft me a two-paragraph reply to the editor. neutral, not eager.' },
    { who: 'ai',   text: 'Drafting into `drafts/editor-reply-2026-05-19.md`. I\u2019ll keep it neutral \u2014 acknowledging the pitch, naming the angle you\u2019re actually interested in, and proposing a timeline that doesn\u2019t overpromise. Back in a moment.' },
    { who: 'tool', text: 'write  drafts/editor-reply-2026-05-19.md  (queued for review)' },
  ],
};

window.SEED = {
  TASKS: SEED_TASKS,
  JOURNAL: SEED_JOURNAL,
  FEED: SEED_FEED,
  THREADS: SEED_THREADS,
  PULSE: SEED_PULSE,
  VITALS: SEED_VITALS,
  THREAD_VIEW: SEED_THREAD_VIEW,
};
