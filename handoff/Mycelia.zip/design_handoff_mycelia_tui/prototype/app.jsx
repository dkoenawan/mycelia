// app.jsx — mycelia workspace

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentHue": "teal",
  "fontFamily": "JetBrains Mono",
  "showThreads": true,
  "showPulse": true,
  "aiProfile": "read"
}/*EDITMODE-END*/;

// Accent palettes (oklch-friendly hex)
const ACCENT_HUES = {
  teal:  { dim: '#4a8a82', main: '#7fd1c4', strong: '#9be9da', glow: 'rgba(127, 209, 196, .55)' },
  gold:  { dim: '#8a7340', main: '#d4b56a', strong: '#ecd28a', glow: 'rgba(212, 181, 106, .55)' },
  lilac: { dim: '#6b6a8a', main: '#a8a6d8', strong: '#c4c2ee', glow: 'rgba(168, 166, 216, .55)' },
  olive: { dim: '#7a8a4a', main: '#c4d47a', strong: '#dcec98', glow: 'rgba(196, 212, 122, .55)' },
};

const FONT_STACKS = {
  'JetBrains Mono': "'JetBrains Mono', ui-monospace, monospace",
  'IBM Plex Mono':  "'IBM Plex Mono', ui-monospace, monospace",
  'Share Tech Mono':"'Share Tech Mono', ui-monospace, monospace",
  'Space Mono':     "'Space Mono', ui-monospace, monospace",
};

const PANEL_KEYS = ['today', 'journal', 'feed', 'threads', 'pulse'];
const PANEL_TITLES = {
  today:   'Today',
  journal: 'Journal',
  feed:    'Feed',
  threads: 'Threads',
  pulse:   'Pulse',
};

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // apply accent + font as CSS vars on :root
  useEffect(() => {
    const root = document.documentElement.style;
    const hue = ACCENT_HUES[t.accentHue] || ACCENT_HUES.teal;
    root.setProperty('--accent',        hue.main);
    root.setProperty('--accent-dim',    hue.dim);
    root.setProperty('--accent-strong', hue.strong);
    root.setProperty('--accent-glow',   hue.glow);
    root.setProperty('--mono', FONT_STACKS[t.fontFamily] || FONT_STACKS['JetBrains Mono']);
  }, [t.accentHue, t.fontFamily]);

  useCellMeasurement(t.fontFamily);

  // state
  const [focus, setFocus] = useState('command');        // 'command' | panel key
  const [selectedTask, setSelectedTask] = useState(SEED.TASKS[0].id);
  const [openThreadId, setOpenThreadId] = useState(null);
  const [cmd, setCmd] = useState('');
  const [feedback, setFeedback] = useState(null);       // { type, text }
  const [feed, setFeed] = useState(SEED.FEED);

  const cmdInputRef = useRef(null);

  // visible panel set (driven by tweaks)
  const visiblePanels = useMemo(() => {
    const set = ['today', 'journal', 'feed'];
    if (t.showThreads) set.push('threads');
    if (t.showPulse)   set.push('pulse');
    return set;
  }, [t.showThreads, t.showPulse]);

  // ─── focus management ───
  const focusCommand = useCallback(() => {
    setFocus('command');
    setTimeout(() => cmdInputRef.current && cmdInputRef.current.focus(), 0);
  }, []);

  const cyclePanel = useCallback((dir) => {
    setFocus((prev) => {
      const order = visiblePanels;
      if (prev === 'command' || !order.includes(prev)) return order[0];
      const i = order.indexOf(prev);
      const next = order[(i + dir + order.length) % order.length];
      return next;
    });
  }, [visiblePanels]);

  // global keyboard
  useEffect(() => {
    const onKey = (e) => {
      // when typing in the command bar, only Esc/Tab matter (Tab handled in input)
      const inCmd = document.activeElement === cmdInputRef.current;

      if (e.key === 'Escape') {
        if (openThreadId) {
          // first Esc dismisses thread back to workspace
          setOpenThreadId(null);
          focusCommand();
          e.preventDefault();
          return;
        }
        focusCommand();
        e.preventDefault();
        return;
      }

      if (inCmd) return;

      // Tab cycles panels
      if (e.key === 'Tab') {
        e.preventDefault();
        cyclePanel(e.shiftKey ? -1 : 1);
        return;
      }

      // Ctrl-1..5 jump to panel
      if (e.ctrlKey && /^[1-5]$/.test(e.key)) {
        e.preventDefault();
        const idx = parseInt(e.key, 10) - 1;
        const target = PANEL_KEYS[idx];
        if (target && visiblePanels.includes(target)) setFocus(target);
        return;
      }

      // ? -> help (just flash feedback for now)
      if (e.key === '?' && !openThreadId) {
        setFeedback({ type: 'info', text: '? help is a planned modal — try / for slash commands' });
        return;
      }

      // task-panel keys
      if (focus === 'today' && !openThreadId) {
        if (e.key === 'j' || e.key === 'ArrowDown') {
          e.preventDefault();
          const i = SEED.TASKS.findIndex(x => x.id === selectedTask);
          const next = SEED.TASKS[Math.min(SEED.TASKS.length - 1, i + 1)];
          setSelectedTask(next.id);
          return;
        }
        if (e.key === 'k' || e.key === 'ArrowUp') {
          e.preventDefault();
          const i = SEED.TASKS.findIndex(x => x.id === selectedTask);
          const next = SEED.TASKS[Math.max(0, i - 1)];
          setSelectedTask(next.id);
          return;
        }
        if (e.key === 'x') {
          e.preventDefault();
          const task = SEED.TASKS.find(x => x.id === selectedTask);
          if (task) {
            setFeedback({ type: 'task', text: `✓ marked done — ${task.title}` });
            pushFeed({ kind: 'task', text: `✓ ${task.title}` });
          }
          return;
        }
      }

      // threads-panel keys
      if (focus === 'threads' && !openThreadId) {
        if (e.key === 'Enter') {
          e.preventDefault();
          setOpenThreadId(SEED.THREADS[0].id);
          return;
        }
      }
    };

    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [focus, selectedTask, openThreadId, cyclePanel, focusCommand, visiblePanels]);

  // initial focus
  useEffect(() => { focusCommand(); }, []);  // eslint-disable-line

  const pushFeed = useCallback((entry) => {
    const now = new Date();
    const time = now.toTimeString().slice(0, 5);
    setFeed((f) => [{ time, ...entry }, ...f].slice(0, 30));
  }, []);

  // ─── command grammar ───
  const handleSubmit = useCallback((raw) => {
    const text = (raw || '').trim();
    if (!text) return;
    let entry = null;

    if (text.startsWith('/')) {
      const head = text.split(/\s+/)[0];
      const rest = text.slice(head.length).trim();
      if (head === '/todo' && rest.startsWith('add')) {
        entry = { kind: 'task', text: `+ added  ${rest.replace(/^add\s+/, '')}` };
        setFeedback({ type: 'ok', text: `task added — ${rest.replace(/^add\s+/, '')}` });
      } else if (head === '/ask' || head === '/think') {
        entry = { kind: 'ai', text: `claude ${head} — "${rest.slice(0, 48)}"` };
        setFeedback({ type: 'ok', text: `started thread — claude · read` });
      } else if (head === '/draft') {
        entry = { kind: 'ai', text: `claude /draft — "${rest.slice(0, 48)}"` };
        setFeedback({ type: 'ok', text: `drafting — see review queue when ready` });
      } else if (head === '/in') {
        entry = { kind: 'note', text: `inbox  ← ${rest.slice(0, 48)}` };
        setFeedback({ type: 'ok', text: `captured to inbox` });
      } else if (head === '/sync') {
        entry = { kind: 'sync', text: `manual sync — 0 changes` };
        setFeedback({ type: 'ok', text: `synced` });
      } else if (head === '/review') {
        setFeedback({ type: 'info', text: `review queue — 3 items (planned screen)` });
      } else if (head === '/find') {
        setFeedback({ type: 'info', text: `search "${rest}" — overlay planned` });
      } else if (head === '/help') {
        setFeedback({ type: 'info', text: `help — Tab / Ctrl-1..5 / Esc · / commands · ?ask · !shell` });
      } else {
        setFeedback({ type: 'warn', text: `unknown command: ${head}` });
      }
    } else if (text.startsWith('?')) {
      const q = text.slice(1).trim();
      entry = { kind: 'ai', text: `claude ?ask — "${q.slice(0, 48)}"` };
      setFeedback({ type: 'ok', text: `→ active thread · claude · read` });
    } else if (text.startsWith('!')) {
      entry = { kind: 'sync', text: `shell  $ ${text.slice(1).trim()}` };
      setFeedback({ type: 'ok', text: `executed (output to feed)` });
    } else {
      // plain text → journal
      entry = { kind: 'note', text: `journal  ← ${text.slice(0, 56)}${text.length > 56 ? '…' : ''}` };
      setFeedback({ type: 'ok', text: `appended to today's journal` });
    }

    if (entry) pushFeed(entry);
    setCmd('');
  }, [pushFeed]);

  // ghost completion
  const ghost = useMemo(() => completeCommand(cmd), [cmd]);

  // active task count for the today panel
  const activeTaskCount = SEED.TASKS.filter(x => x.status !== 'done').length;

  // ─── render ───
  if (openThreadId) {
    return (
      <div className="app">
        <StatusBar
          reviewCount={3}
          syncState="ok"
          dateString={SEED.JOURNAL.date}
        />
        <ThreadView thread={SEED.THREAD_VIEW} />
        <CommandBar
          inputRef={cmdInputRef}
          value={cmd}
          onChange={setCmd}
          onSubmit={(v) => {
            // in thread view: prefix-less text sends to thread; / and ! still slash/shell
            if (!v.startsWith('/') && !v.startsWith('!')) {
              pushFeed({ kind: 'ai', text: `↳ you — "${v.slice(0, 48)}"` });
              setCmd('');
              setFeedback({ type: 'ok', text: `sent to thread` });
              return;
            }
            handleSubmit(v);
          }}
          mode={t.aiProfile}
          ghost={ghost}
          placeholder='reply to thread · /command · Esc to return'
        />
      </div>
    );
  }

  return (
    <div className="app">
      <StatusBar
        reviewCount={3}
        syncState="ok"
        dateString={SEED.JOURNAL.date}
      />

      <div className={`workspace ${!t.showThreads ? 'no-threads' : ''} ${!t.showPulse ? 'no-pulse' : ''}`}>
        <Panel
          title="today"
          count={activeTaskCount}
          focused={focus === 'today'}
          focusGlyph
          bodyScroll
          className="panel-today"
          onClick={() => setFocus('today')}
        >
          {SEED.TASKS.map((task) => (
            <TaskLine
              key={task.id}
              task={task}
              selected={focus === 'today' && selectedTask === task.id}
            />
          ))}
        </Panel>

        <Panel
          title="journal"
          focused={focus === 'journal'}
          focusGlyph
          bodyScroll
          className="panel-journal span-rows-2"
          onClick={() => setFocus('journal')}
        >
          <div className="dim2" style={{ marginBottom: 'calc(var(--lh) * 0.4)' }}>
            ── {SEED.JOURNAL.date} ──
          </div>
          <JournalDoc journal={SEED.JOURNAL} />
        </Panel>

        <Panel
          title="feed"
          focused={focus === 'feed'}
          focusGlyph
          bodyScroll
          className="panel-feed span-rows-2"
          onClick={() => setFocus('feed')}
        >
          <FeedBoard feed={feed} />
        </Panel>

        {t.showThreads ? (
          <Panel
            title="threads"
            count={SEED.THREADS.filter(t => t.unread).length || null}
            focused={focus === 'threads'}
            focusGlyph
            bodyScroll
            className="panel-threads lower"
            onClick={() => setFocus('threads')}
          >
            {SEED.THREADS.filter(t => t.active).map((th) => (
              <ActiveThreadBlock key={th.id} thread={th} />
            ))}
            {SEED.THREADS.filter(t => !t.active).map((th) => (
              <ThreadItem
                key={th.id}
                thread={th}
                onOpen={() => setOpenThreadId(th.id)}
              />
            ))}
          </Panel>
        ) : null}

        {t.showPulse ? (
          <Panel
            title="pulse"
            focused={focus === 'pulse'}
            focusGlyph
            bodyScroll
            className="panel-pulse lower"
            onClick={() => setFocus('pulse')}
          >
            <PulseBoard pulse={SEED.PULSE} />
          </Panel>
        ) : null}
      </div>

      <VitalsBar vitals={SEED.VITALS} />

      <CommandBar
        inputRef={cmdInputRef}
        value={cmd}
        onChange={setCmd}
        onSubmit={handleSubmit}
        mode={t.aiProfile}
        ghost={ghost}
      />

      {feedback ? (
        <FeedbackToast feedback={feedback} onDone={() => setFeedback(null)} />
      ) : null}

      <MyceliaTweaks t={t} setTweak={setTweak} />
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Feedback toast — sits just above the command bar
function FeedbackToast({ feedback, onDone }) {
  useEffect(() => {
    const id = setTimeout(onDone, 2200);
    return () => clearTimeout(id);
  }, [feedback, onDone]);
  const color =
    feedback.type === 'ok'   ? 'var(--success)' :
    feedback.type === 'warn' ? 'var(--warning)' :
    feedback.type === 'err'  ? 'var(--danger)'  :
    'var(--accent)';
  return (
    <div style={{
      position: 'fixed',
      bottom: 'calc(var(--lh) * 2 + 8px)',
      left: 'calc(var(--ch) * 4)',
      color,
      background: 'var(--bg)',
      padding: '0 1ch',
      zIndex: 50,
      fontSize: 12,
      letterSpacing: '.02em',
      textShadow: feedback.type === 'ok' ? '0 0 6px var(--accent-glow)' : 'none',
    }}>
      ▸ {feedback.text}
    </div>
  );
}

// ghost-complete: trivial command completion for the bar
function completeCommand(input) {
  if (!input || !input.startsWith('/')) return '';
  const cmds = [
    '/todo add ', '/todo done ', '/todo list',
    '/note new ', '/note find ',
    '/journal yesterday',
    '/in ',
    '/ask ', '/think ', '/draft ',
    '/tag ', '/triage inbox',
    '/agent ', '/review', '/sync', '/find ', '/help',
  ];
  const hit = cmds.find(c => c.startsWith(input) && c !== input);
  return hit || '';
}

// ─────────────────────────────────────────────────────────────────────────────
// Tweaks panel
function MyceliaTweaks({ t, setTweak }) {
  return (
    <TweaksPanel>
      <TweakSection label="Aesthetic" />
      <TweakColor
        label="Accent"
        value={ACCENT_HUES[t.accentHue].main}
        options={Object.values(ACCENT_HUES).map(h => h.main)}
        onChange={(v) => {
          const key = Object.keys(ACCENT_HUES).find(k => ACCENT_HUES[k].main === v);
          if (key) setTweak('accentHue', key);
        }}
      />
      <TweakSelect
        label="Mono font"
        value={t.fontFamily}
        options={Object.keys(FONT_STACKS)}
        onChange={(v) => setTweak('fontFamily', v)}
      />

      <TweakSection label="Layout" />
      <TweakToggle
        label="Threads panel"
        value={t.showThreads}
        onChange={(v) => setTweak('showThreads', v)}
      />
      <TweakToggle
        label="Pulse panel"
        value={t.showPulse}
        onChange={(v) => setTweak('showPulse', v)}
      />

      <TweakSection label="AI profile" />
      <TweakRadio
        label="Active"
        value={t.aiProfile}
        options={['read', 'draft', 'act']}
        onChange={(v) => setTweak('aiProfile', v)}
      />
    </TweaksPanel>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Mount
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
